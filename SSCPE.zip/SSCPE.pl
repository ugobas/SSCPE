#!/usr/bin/env perl 
use strict;
use warnings;
use Getopt::Long;
use Cwd qw(getcwd);
use File::Copy;
use File::Basename;
use Config;
use FindBin;

# Authors: Ugo Bastolla <ubastolla@cbm.csic.es> and Miguel Arenas <marenas@uvigo.es>

# path to programs and databases, modify as needed:
my $dir_SSCPE="/home/ubastolla/RESEARCH/PROT_EVOL/SSCPE/SCRIPTS";

# install programs and data in the above directory:
my $Mut_para="$dir_SSCPE/Mutation_para.in";
my $Prot_evol="$dir_SSCPE/Prot_evol";
my $raxmlng="$dir_SSCPE/raxml-ng";
my $tnm="$dir_SSCPE/tnm";
my $structures="$dir_SSCPE/structures.in";

print "Script $0 Authors: ",
    "Ugo Bastolla <ubastolla\@cbm.csic.es> and ",
    "Miguel Arenas <marenas\@uvigo.es>\n",
    "It needs as input a MSA file (-msa) and a pdb file (-pdb), ",
    "it runs the programs tnm and Prot_evol (or reuses previous results ",
    "if they exist and -reuse is set), it generates site-specific ",
    "stability and structure constrained (SSCPE) substitution matrices, ",
    "it transofrms them in format readble by the programs RAxML-NG and PAML ",
    "and it runs these programs upon request (-raxmlng, -paml) if they ",
    "are installed in the directory $dir_SSCPE\n\n";

# Input arguments
my $msa="";
my $pdb="";
my $chain="";
my $reuse=0;    # Reuse previous results if they exist
my $runraxml=0; # Run RAxML-NG for phylogenetic analysis
my $thread=0;   # Number of threads of raxmlng
my $clean=0;    # Clean site-specific matrices after running raxmlng

# Output
my $partition_file="partitionsSite.txt"; # Output file

if(scalar(@ARGV)<2){help();}
chomp($ARGV[scalar(@ARGV)-1]);
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-pdb"){
	$i++; $pdb=$ARGV[$i];
    }elsif($ARGV[$i] eq "-msa"){
	$i++; $msa=$ARGV[$i];
    #}elsif($ARGV[$i] eq "-pdbdir"){
    #	$i++; $pdbdir=$ARGV[$i];
    }elsif($ARGV[$i] eq "-chain"){
	$i++; $chain=$ARGV[$i];
    }elsif($ARGV[$i] eq "-reuse"){
	$reuse=1;
    }elsif(substr($ARGV[$i],0,6) eq "-raxml"){
	$runraxml=1;
    }elsif($ARGV[$i] eq "-thread"){
    	$i++; $thread=$ARGV[$i];
    }elsif($ARGV[$i] eq "-h"){
	help();
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
if($pdb eq ""){
    print "ERROR, PDB file must be provided with option -pdb <file>\n";
    help();
}
if($msa eq ""){
    print "ERROR, alignment file must be provided with option -msa <file>\n";
    help();
}


my @word=split(/\//, $pdb);
my $pdbcode=substr($word[scalar(@word)-1],0,4);

@word=split(/\//, $msa);
my $msa_1=substr($word[scalar(@word)-1],0);
print "Alignment: ",$msa_1," Reference protein: ",$pdbcode,$chain,"\n";

# Prepare directories
getcwd(); my $maindir=`pwd`; print "Working directory: ", $maindir;
chomp $maindir;
if(substr($pdb,0,1) ne "/"){$pdb="$maindir/$pdb";}
print "PDB file: ",$pdb,"\n";

if(substr($msa,0,1) ne "/"){$msa="$maindir/$msa";}
print "MSA file: ",$msa,"\n\n";

my $dirstore=$pdbcode;
unless(-d $dirstore){
    `mkdir $dirstore`; print "Creating folder ",$dirstore,"\n";
}
# copy MSA to directory dirstore
my $dmsa=sprintf("%s/%s", $dirstore, $msa);
unless(-e $dmsa){`cp $msa $dirstore`;}

# Define variables
my $name;
my $file_RMSD=""; my $file_DE=""; my $file_summ_tnm="";
my $file_summ_Prot_evol="";
my $file_StabCPE=""; my $file_StrCPE=""; my $file_SSCPE="";
my $file_rate_StabCPE=""; my $file_rate_StrCPE=""; my $file_rate_SSCPE="";
my $StabCPE=""; my $StrCPE=""; my $SSCPE="";

# Check if TNM results exist, otherwise run TNM
if($reuse){
    print "Checking if TNM results exist in folder ",$dirstore,"\n";
    Get_files_TNM($dirstore);
}
if($file_RMSD ne ""){
    print "TNM results exist\n";
}else{
    # TNM results do not exist, run the tnm program
    Run_TNM();
}
print "TNM results:\n", $file_RMSD,"\n", $file_DE,"\n", $file_summ_tnm,"\n";

if($reuse){
# Check if Prot_evol results exist, otherwise run Prot_evol
    print "Checking if Prot_evol results exist in folder ",$dirstore,"\n";
    Get_files_Prot_evol($dirstore);
}
if($file_SSCPE){
    # Prot_evol results exist, use them
    print "Prot_evol results exist\n";
}else{
    # Prot-evol results do not exist, run the program
    Run_Prot_evol();
}
print "Prot_evol results:\n", $file_summ_Prot_evol,"\n",
    $file_SSCPE,"\n", $file_StrCPE,"\n", $file_StabCPE,"\n",
    $file_rate_SSCPE,"\n", $file_rate_StrCPE,"\n", $file_rate_StabCPE,"\n",
    "\n";
$name=substr($file_SSCPE,0,5);

chdir $dirstore;
my $subdir=`pwd`; print "Working directory: ", $subdir;

# Count number of sites
open(my $fh, '<:encoding(UTF-8)', $file_SSCPE)
or die "Could not open file '$file_SSCPE' $!";
my $length=0;
while (my $row = <$fh>){if(substr($row,0,4) eq "SITE"){$length++;}}
print $length," amino-acid sites found in file ",$file_SSCPE,"\n";
close $fh;

# Convert format
my $msa_2=Remove_extension($msa_1);
$msa_2=sprintf ("%s_OneLine.fasta", $msa_2);
FastaManyLines_FastaOneLine($msa_1, $msa_2);

my $msa_3=Remove_extension($msa_2);
$msa_3=sprintf ("%s_Nogap.fasta", $msa_3);
my $naa_1=RemakeAlnsWithoutGapsFirstSeq($msa_2, $msa_3);
if($naa_1 != $length){
    print "ERROR, different number of sites in model $file_SSCPE ($length)",
    "and in purged MSA $msa_3 ($naa_1)\n"; die;
}

my $MyModel=sprintf("%s_SSCPE", $name);
Make_partition($length, $partition_file);
MatricesFile_FromProtEvol_to_PAML($file_SSCPE, $length);

# Run RAxML-NG
my $command;
if($runraxml){

    $command=
	"$raxmlng --search --msa $msa_3 --model $partition_file --brlen linked";
    #my $nsite=150; # 150 sites per thread
    #if($thread<=0){
    #	if($length>150){$thread=$length/150;}else{$thread=1;}
    #}
    if($thread){$command=sprintf("%s --threads %d", $command, $thread);}

    print $command, "\n";
    system($command);

    #`$raxml --search --msa $msa_3 --model JTT +FC +G --opt-model off`;
    # For JTT

    if($clean){`rm -f $MyModel*.txt`;}
}

exit;

sub help{

    print "ERROR, PDB file and alignment file must be specified\n";
    print
	"USAGE: ",$0,,
	" -msa <MSA file> (FASTA)",
	" -pdb <PDB file>",
	" -chain <PDB chain> (default: first chain)",
	" -reuse (reuse data that already exist)",
	" -raxml (run RAxML-NG)",
	" -clean (clean matrices per site after using them)",
	" -thread (number of processors used by RAxML-NG)",
	"\n";
    die;
}

sub Get_file{ #($dirstore, ".tnm.summary.")
    my $tmp=`ls -1 $_[0]/*$_[1]*`; chomp($tmp);
    if(substr($tmp,0,3) eq "ls:"){return("");}
    my @word=split(/\//, $tmp); my $w=scalar(@word);
    #print "File: ",$tmp,"\n"; 
    #print $w; if($w>1){print " ", $word[$w-1];} print "\n";
    if($w>1){return($word[$w-1]);}
    else{return("");}
}

sub Make_partition{ # $length, $partition_file

    my $length=$_[0]; my $output=$_[1];
    print "Making partitions for sites 1-",$length,
    ", output: ",$output,"\n";
    open (my $fo,'>',$output);
    for (my $s=1; $s<=$length; $s++){
	my $out=sprintf("PROTGTR{%s_site_%d.txt}, p%d = %d-%d\n",
			$MyModel, $s, $s, $s, $s);
	print $fo $out;
    }
    close $fo;
    return;
}

sub MatricesFile_FromProtEvol_to_PAML{ #$_[0]=$file_SSCPE $_[1]=$length
    print "Converting Matrix files From ProtEvol to PAML format\n";
    # Author: Miguel Arenas (2014, CBMSO, CSIC-UAM Madrid)"

# Loading input file with matrices from Prot_evol
    my $file = $_[0];
    unless (open(FROM,$file)){
	print STDERR "Cannot open file \"$file\"\n\n"; die;
    }
    print "Matrices file uploaded: $file $_[1] sites\n";	

    print "Writing one matrix per each site: ";
    my $WorkingSite=0;
    my $Site=0;
    my $Line=0;
    open(FROM, $file);
    while (<FROM>){
	#$Lines++;
	# Detect site
	if ($_ =~ /^SITE/){
	    my @seq1 = split(/\s+/, $_);
	    my $PDBSite = $seq1[1];
	    if ($Site){
		#print FILE_2 "\n";
		#print FILE_2 "// this is the end of the file. ",
		#"The rest are notes\n";
		#print FILE_2 " A   R   N   D   C   Q   E   G   H   I   ",
		#"L   K   M   F   P   S   T   W   Y   V \n";
		#print FILE_2 "\n";
		#print FILE_2 "Matrix generated under the ",
		#"structurally constrained substitution model\n";
		close (FILE_2);	
	    }
	    $Site++; print "$Site ";
	    my $createdFile = sprintf ("%s_site_%d.txt",$MyModel,$Site);
	    open (FILE_2,'>',$createdFile);
	    $Line=0;
	}else{
	    $Line++; 
	    if($Line<=22){print FILE_2 $_;}
	}	
    } # end of lines FROM
    print "\nModels have been written in $MyModel\_site_X.txt\n";
    print "Finished\n\n";

    close (FILE_2);
    close (FROM);
}

sub FastaManyLines_FastaOneLine{ #$_[0]=Input $_[1]=Output

    print "Converting MSA to one line format\n";

# opening lines of input files
    my $Input = $_[0];
    unless (open(FROM,$Input)){
	print STDERR "Cannot open file \"$Input\"\n\n";
    }

# Reading input file 
    print "Loading $Input\n";

    my $newfile_tree = $_[1];
    open (FILE_OUTPUT,">$newfile_tree");

    my $NumberSites = 0;
    my @AALong_SequenceHere1;
    my @AALong_HeadSeqHere1;

    my $SeqNumber = 0;    
    while (<FROM>){
	if ($_ =~ />/){
	    $SeqNumber++;
	    if ($SeqNumber > 1){print FILE_OUTPUT "\n";}
        
	    my $TaxaName = $_;
	    $TaxaName =~ s/\n//g; # remove the end of line
	    $TaxaName =~ s/\s//g; # remove blank site
	    $AALong_HeadSeqHere1[$SeqNumber] = $TaxaName;
            
	    print FILE_OUTPUT $_;   
        }else{
	    my $sequenceHere = $_;
	    $sequenceHere =~ s/\n//g; # remove the end of line
	    $sequenceHere =~ s/\s//g; # remove blank site
	    $NumberSites = length($sequenceHere);
	    $AALong_SequenceHere1[$SeqNumber] = $sequenceHere;
	    print FILE_OUTPUT "$sequenceHere";
        }		
    }
    print FILE_OUTPUT "\n";
    close (FROM);
    close (FILE_OUTPUT);
    print "Finished\n\n";
    return;
}
	
sub RemakeAlnsWithoutGapsFirstSeq_Ugo{

# It does not assume that the fasta file contains only one line per sequence
    my $AAFileName1=$_[0];
    print "Remaking alignment $_[0] without columns with gaps in first seq.\n";
    
# opening lines of input files
    unless (open(FROM,$AAFileName1)){
	print STDERR "Cannot open file \"$AAFileName1\"\n\n"; die;
    }

    my $newfile_ALN = $_[1];
    open (FILE_OUTPUT,">$newfile_ALN");

    my @gapPos;
    my $NumberGapsPos = 0;
    my $SeqNumber = 0;
    my $num_aa=0;
    open(FROM,$AAFileName1);
    while (<FROM>){ # for each line
	if ($_ =~ />/){
	    if($SeqNumber){print FILE_OUTPUT "\n";}
	    $SeqNumber++;
	    $num_aa=0;
	    print FILE_OUTPUT $_;
	}else{
# identify sites with gaps and print only the sequence without gaps
	    my $ThisSeq_1 = $_;
	    $ThisSeq_1 =~ s/\n//g; # remove the end of line
	    $ThisSeq_1 =~ s/\s//g; # remove blank site
	    my @AASeq = split ('', $ThisSeq_1);
	    if($SeqNumber==1){
		# Identify columns with gaps
		my $l=length($ThisSeq_1); $num_aa+=$l;
		for (my $AAn = 0; $AAn < $l; $AAn++){
		    if ($AASeq[$AAn] ne "-"){$gapPos[$AAn]=0;}
		    else{$gapPos[$AAn]=1; $NumberGapsPos++;}
		}
	    }
	    for (my $AAn = 0; $AAn < length($ThisSeq_1); $AAn++){
		if ($gapPos[$AAn]==0){		    
		    print FILE_OUTPUT "$AASeq[$AAn]";
                }
            }
        }

    }
    print FILE_OUTPUT "\n";

    # Print columns with gap
    print "Columns with gaps: ";
    for (my $n = 0; $n < $num_aa; $n++){
	if($gapPos[$n]){print "$n ";}
    }
    print "\n";
    close (FROM);
    close (FILE_OUTPUT);
    return $num_aa;
}

sub RemakeAlnsWithoutGapsFirstSeq{
# It assumes that the fasta file contains only one line per sequence

    my $AAFileName1=$_[0];
    print "Remaking alignment $_[0] without columns with gaps in first seq.\n";

    my $newfile_ALN = $_[1];
    open (FILE_OUTPUT,">$newfile_ALN");
    
# opening lines of input files
    unless (open(FROM,$AAFileName1)){
	print STDERR "Cannot open file \"$AAFileName1\"\n\n"; die;
    }

    my $col_number = -1;
    my $aa_number1=0;
    my $SeqNumber = 0;
    
    my @gapPos;
    my $NumberGapsPos = 0;
    my $counterLines=0;
    while (<FROM>){
	$counterLines++;
	if($_ =~ />/){
	    print FILE_OUTPUT $_; $SeqNumber++;
	}else{
	    my $ThisSeq_1 = $_;
	    $ThisSeq_1 =~ s/\n//g; # remove the end of line
	    $ThisSeq_1 =~ s/\s//g; # remove blank site
	    my @AASeq = split ('', $ThisSeq_1);

	    if($SeqNumber == 1){
		# identify columns with gaps and print only col without gaps
		$col_number = length($ThisSeq_1);
		print "Total number of columns: $col_number \n";
		
		for (my $AAn = 0; $AAn < $col_number; $AAn++){
		    if ($AASeq[$AAn] eq "-"){
			$NumberGapsPos++;
			$gapPos[$AAn] = 1;
		    }else{
			$gapPos[$AAn] = 0;
		    }
		}
		$aa_number1 = $col_number-$NumberGapsPos;
		print "Excluding gaps in first sequence: ", $aa_number1,"\n";
	    }
            
	    for (my $AAn = 0; $AAn < $col_number; $AAn++){
                if ($gapPos[$AAn] == 0){
		    print FILE_OUTPUT "$AASeq[$AAn]";
                }
            }
	    print FILE_OUTPUT "\n";
        }
    }

    close (FROM);
    close (FILE_OUTPUT);
    
    print "Columns with gaps: ";
    for (my $n = 0; $n < $col_number; $n++){
	if($gapPos[$n]){print "$n ";}
    }
    print "\n\n";
    return $aa_number1;
}


sub ModelsFromDATtoRAxMLng2{
### Programmer: Miguel Arenas Busto. March, 2019.
### Version 2.0 
###
    print "Converting to RAxML format\n";
    my @filesDat = <*.dat>;
    foreach my $file (@filesDat){ # for each .dat file
	my $newfile_rates = $file;
	$newfile_rates = sprintf ("%s.txt", $file);
	open (FILE_OUTPUT,">$newfile_rates");
	my @EntireFile = ();
	my $countLinesEntireFile = 0;
	my $line_position = 0;
	unless (open(FROM,$file)){
	    print STDERR "Cannot open file \"$file\"\n\n";
	}
	while (<FROM>){
	    $countLinesEntireFile++;
	    $EntireFile[$countLinesEntireFile] = $_;
	} 
	# now print the files
	for (my $n = 1; $n <= $countLinesEntireFile; $n++){
	    my $sequenceLineHere = $EntireFile[$n];
	    if ($n < 22){
		print FILE_OUTPUT $sequenceLineHere;
	    }
	}      
	close (FILE_OUTPUT);
	close (FROM);
    }
    #system ("rm *.dat");
    print "Finished\n\n";
    return;
}

sub Get_files_TNM{ #0=$dirstore
    my $dir=$_[0];
    $file_RMSD=Get_file($dir, "_RMSD.dat");
    if($file_RMSD eq ""){return;}
    $file_DE=  Get_file($dir, "_DE.dat");
    $file_summ_tnm=Get_file($dir, ".tnm.summary.");
}

sub Get_files_Prot_evol{ #0=$dirstore
    my $dir=$_[0];
    $SSCPE="RMSDWT";
    my $tmp=sprintf("_%s_exchangeability_sites", $SSCPE);
    $file_SSCPE=Get_file($dir, $tmp);
    if($file_SSCPE eq ""){
	$SSCPE="RMSDMF";
	$tmp=sprintf("_%s_exchangeability_sites", $SSCPE);
	$file_SSCPE=Get_file($dir, $tmp);
    }
    if($file_SSCPE eq ""){
	$SSCPE="DEWT";
	$tmp=sprintf("_%s_exchangeability_sites", $SSCPE);
	$file_SSCPE=Get_file($dir, $tmp);
    }
    if($file_SSCPE eq ""){
	$SSCPE="DEMF";
	$tmp=sprintf("_%s_exchangeability_sites", $SSCPE);
	$file_SSCPE=Get_file($dir, $tmp);
    }
    if($file_SSCPE eq ""){return;}
    $tmp=sprintf("_%s_rate_profile", $SSCPE);
    $file_rate_SSCPE=Get_file($dir, $tmp);

    $StabCPE="WT";
    $tmp=sprintf("_%s_exchangeability_sites", $StabCPE);
    $file_StabCPE=Get_file($dir, $tmp);
    if($file_StabCPE eq ""){
	$StabCPE="MF";
	$tmp=sprintf("_%s_exchangeability_sites", $StabCPE);
	$file_StabCPE=Get_file($dir, $tmp);
    }
    $tmp=sprintf("_%s_rate_profile", $StabCPE);
    $file_rate_StabCPE=Get_file($dir, $tmp);

    $StrCPE="RMSD";
    $tmp=sprintf("_%s_exchangeability_sites", $StrCPE);
    $file_StrCPE=Get_file($dir, $tmp);
    if($file_StrCPE eq ""){
	$StrCPE="DE";
	$tmp=sprintf("_%s_exchangeability_sites", $StrCPE);
	$file_StrCPE=Get_file($dir, $tmp);
    }
    $tmp=sprintf("_%s_rate_profile", $StrCPE);
    $file_rate_StrCPE=Get_file($dir, $tmp);

    $file_summ_Prot_evol=Get_file($dir, "_Prot_evol_summary.dat");
    return;
}

sub Run_Prot_evol{

    # Prepare configuration file for Prot_evol
    my $input=sprintf("Input_Prot_evol_%s.in", $pdbcode);
    open(my $fo, '>', $input);
    print $fo "ALI= ../",$dirstore,"/",$msa_1,"\n";
    print $fo "PDB= ",$pdb,"\n";
    if($chain){print $fo "CHAIN= ",$chain,"\n";}
    if($file_RMSD){print $fo "STR_MUT= ../",$dirstore,"/",$file_RMSD,"\n";}
    if($file_DE){print $fo "STR_MUT= ../",$dirstore,"/",$file_DE,"\n";}
    print $fo "MF_COMP=0\n";
    print $fo "MATRIX=JTT\n";
    print $fo "EXCHANGE=FLUX\n";
    print $fo "MEANFIELD= 1\n";
    print $fo "PRINT_E=1\n";
    print $fo "OPT_REG= 1\n";
    print $fo "SCORE_CV= 0\n";
    print $fo "REG=0.05\n";
    print $fo "REMUT=1\n";
    print $fo "GET_FREQ=3\n";
    print $fo "FILE_STR= ",$dir_SSCPE,"/structures.in\n";
    print $fo "A_LOC= 1            # Use secondary structure propensities?\n";
    print $fo "TEMP=  1.0	   # Temperature\n";
    print $fo "SU1=   0.13	   # config. entropy per res (unfold)\n";
    print $fo "SC1=  0.065	   # config. entropy per res (misfold)\n";
    print $fo "SC0=  0.0	   # config. entropy offset (misfold)\n";
    print $fo "REM=   2	           # Use 0,1,2 moments of misfolding energy\n";
    close $fo;
    print "Configuration file for Prot_evol: ", $input, "\n";

    my $dir_tmp=sprintf("tmp_%s", $pdbcode);
    unless(-d $dir_tmp){
	`mkdir $dir_tmp`;  print "Creating folder ",$dir_tmp,"\n";
    }
    `mv $input $dir_tmp`;
    chdir $dir_tmp;
    my $subdir=`pwd`; print "Working directory: ", $subdir;
    my $command=sprintf("%s %s >> %s.Prot_evol.log\n",
			$Prot_evol, $input, $pdbcode);
    print "Running Prot_evol: ", $command; `$command`;
    print "Finished\n\n";

   # Store results of Prot_evol
    Get_files_Prot_evol(".");
    $name=substr($file_SSCPE,0,5);
    Move_files_Prot_evol("../$dirstore");
    `mv $input ../$dirstore`;

    chdir "..";
    $subdir=`pwd`; print "Working directory: ", $subdir;
    # Clean
    #`rm -rf $dir_tmp`; print "Deleting dir ",$dir_tmp,"\n";
    chdir $dirstore;
    $subdir=`pwd`; print "Working directory: ", $subdir;
}

sub Move_files_Prot_evol
{
    my $dir=$_[0];
    if($file_SSCPE eq ""){
	print "ERROR, results for SSCPE not found for ",$name,"\n"; die;
    }else{
	`mv $file_SSCPE $dir`;
	`mv $file_rate_SSCPE $dir`;
    }
    if($file_StabCPE eq ""){
	print "WARNING, results for StabCPE not found for ",$name,"\n";
    }else{
	`mv $file_StabCPE $dir`;
	`mv $file_rate_StabCPE $dir`;
    }
    if($file_StrCPE eq ""){
	print "WARNING, results for StrCPE not found for ",$name,"\n";
    }else{
	`mv $file_StrCPE $dir`;
	`mv $file_rate_StrCPE $dir`;
    }
    my $file_tmp=Get_file(".", "summary.dat");
    if($file_tmp eq ""){
	print "WARNING, summary of Prot_evol not found for ",$name,"\n";
    }else{
	$file_summ_Prot_evol=sprintf("%s_Prot_evol_summary.dat",$name);
	`mv $file_tmp $dir/$file_summ_Prot_evol`;
    }
}

sub Run_TNM{

    # Prepare configuration file for TNM
    my $input=sprintf("Input_TNM_%s.in", $pdbcode);
    open(my $fo, '>', $input);
    print $fo "PDB1= ",$pdb,"\n";
    if($chain){print $fo "CH1= ",$chain,"\n";}
    print $fo "FIT_B=1           ! Fit force constant from B factors\n";
    print $fo "PRED_MUT=1        ! Predict RMSD of all possible mutations\n";
    print $fo "MUT_PARA=",$Mut_para,"   ! File with mutation parameters\n";
    close $fo;

    # Prepare dir_tmp
    my $dir_tmp=sprintf("tmp_%s", $pdbcode);
    unless(-d $dir_tmp){
	`mkdir $dir_tmp`;  print "Creating folder ",$dir_tmp,"\n";
    }
    `mv $input $dir_tmp`;
    chdir $dir_tmp;
    my $subdir=`pwd`; print "Working directory: ", $subdir;

    $command=sprintf("%s %s > %s.tnm.log\n", $tnm, $input, $pdbcode);
    print "Running TNM: ", $command;
    `$command`; # run the tnm program
    print "Finished\n";

    # Store TNM results
    $name=substr(`ls -1 *summary.dat`,0,5);
    if(substr($name,0,3) eq "ls:"){
	print "ERROR, TNM program could not be run\n"; die;
    }else{
	print "TNM executed for protein chain ",$name,"\n";
    }
    $file_RMSD=sprintf("%s.mut_RMSD.dat",$name);
    $file_DE=sprintf("%s.mut_DE.dat",$name);
    my $file_tmp=sprintf("%s.summary.dat",$name);
    $file_summ_tnm=sprintf("%s.tnm.summary.dat",$name);
    `mv $file_RMSD ../$dirstore`;
    `mv $file_DE ../$dirstore`;
    `mv $file_tmp ../$dirstore/$file_summ_tnm`;
    `mv $input ../$dirstore`;
    chdir "..";
    $subdir=`pwd`; print $subdir;
    # Clean TNM results
    `rm -rf $dir_tmp`;
    print "Deleting TNM results in ",$dir_tmp,"\n";
}

sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out=sprintf("%s.%s",$out,$word[$i]);
    }
    return $out;
}
