#!/usr/bin/env perl 
use strict;
use warnings;
use Getopt::Long;
use Cwd qw(getcwd);
use File::Copy;
use File::Basename;
use Config;
use FindBin;

# Authors: Ugo Bastolla <ubastolla@cbm.csic.es> and Miguel Arenas <marenas@uvigo.es>

# path to programs and databases, modify as needed:
my $dir_SSCPE="/home/ubastolla/RESEARCH/PROT_EVOL/SSCPE/SCRIPTS";
#my $dir_SSCPE="/data/ubastolla/CODES/SSCPE"

# install programs and data in the above directory:
my $Mut_para="$dir_SSCPE/Mutation_para.in";
my $Prot_evol="$dir_SSCPE/Prot_evol";
my $raxmlng="$dir_SSCPE/raxml-ng";
my $tnm="$dir_SSCPE/tnm";
my $structures="$dir_SSCPE/structures.in";

print "Script $0 Authors: ",
    "Ugo Bastolla <ubastolla\@cbm.csic.es> and ",
    "Miguel Arenas <marenas\@uvigo.es>\n",
    "It needs as input a MSA file (-msa) and a pdb file (-pdb), ",
    "it runs the programs tnm and Prot_evol (or reuses previous results ",
    "if they exist, unless -noreuse is set), it generates site-specific ",
    "stability and structure constrained (SSCPE) substitution matrices, ",
    "it transforms them in format readble by the programs RAxML-NG and PAML ",
    "and it runs these programs upon request (-raxmlng, -paml) if they ",
    "are installed in the directory $dir_SSCPE\n\n";

# Input arguments
my $msa="";
my $pdb="";
my $chain="";
my $reuse=1;    # Reuse previous results if they exist
my $runraxml=0; # Run RAxML-NG for phylogenetic analysis
my $thread=0;   # Number of threads of raxmlng
my $clean=1;    # Clean site-specific matrices after running raxmlng
my @rate;
my $setrate=1;
my $option="";
my $model="SSCPE";

# Output
my $partition_file="partitionsSite"; # Output file

if(scalar(@ARGV)<2){help();}
chomp($ARGV[scalar(@ARGV)-1]);
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-pdb"){
	$i++; $pdb=$ARGV[$i];
    }elsif($ARGV[$i] eq "-msa"){
	$i++; $msa=$ARGV[$i];
    #}elsif($ARGV[$i] eq "-pdbdir"){
    #	$i++; $pdbdir=$ARGV[$i];
    }elsif($ARGV[$i] eq "-chain"){
	$i++; $chain=$ARGV[$i];
    }elsif(substr($ARGV[$i],0,6) eq "-raxml"){
	$runraxml=1;
    }elsif($ARGV[$i] eq "-model"){
	$i++; 
	if($ARGV[$i] ne "STAB" && 
	   $ARGV[$i] ne "STRUCT" &&
	   $ARGV[$i] ne "SSCPE"){
	    print "WARNING, $ARGV[$i] is not an allowed model\n",
	    "Only allowed: SSCPE (default) STRUCT STAB\n",
	    "Using default SSCPE\n";
	}else{
	    $model=$ARGV[$i];
	    print "Using model $model of Prot_evol\n";
	}
    }elsif($ARGV[$i] eq "-noclean"){
	$clean=0;
    }elsif($ARGV[$i] eq "-option"){
	$i++; $option=$ARGV[$i];
    }elsif($ARGV[$i] eq "-thread"){
    	$i++; $thread=$ARGV[$i];
    }elsif($ARGV[$i] eq "-noreuse"){
	$reuse=0;
    }elsif($ARGV[$i] eq "-h"){
	help();
    }elsif($ARGV[$i] eq "-rate"){
# 1: BU=site-spec subst.rate; 0: BU=1; -1: BU=1/rate",
	$i++; $setrate=$ARGV[$i];
	print "Site-specific substitution rates: $setrate\n";
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
if($pdb eq ""){
    print "ERROR, PDB file must be provided with option -pdb <file>\n";
    help();
}
if($msa eq ""){
    print "ERROR, alignment file must be provided with option -msa <file>\n";
    help();
}


my @word=split(/\//, $pdb);
my $pdbcode=substr($word[scalar(@word)-1],0,4);
@word=split(/\//, $msa);
my $msa_1=substr($word[scalar(@word)-1],0);

my $prot=sprintf("%s%s", $pdbcode, $chain);
my $MyModel=sprintf("%s_%s_%s_rate%d",
		    $prot, Remove_extension($msa_1), $model, $setrate);

my $nameout=sprintf("%s.log", $MyModel);
open(my $fo, '>', $nameout);
print "Writing log in $nameout\n"; 
my $out=
    sprintf( "Alignment: %s Reference protein: %s\n", $msa_1,$pdbcode,$chain);
print $out; print $fo $out;


# Prepare directories
getcwd();
my $maindir=Print_dir();

if(substr($pdb,0,1) ne "/"){$pdb="$maindir/$pdb";}
$out=sprintf("PDB file: %s\n", $pdb);
print $out; print $fo $out;

if(substr($msa,0,1) ne "/"){$msa="$maindir/$msa";}
$out=sprintf("MSA file: %s\n",$msa);
print $out; print $fo $out;

my $dirstore=sprintf("%s/%s", $maindir, $pdbcode);
$out=sprintf("Results are stored in folder %s\n",$dirstore);
print $out; print $fo $out;

unless(-d $dirstore){
    `mkdir $dirstore`;
    $out=sprintf("Creating folder %s\n",$dirstore);
}else{
    $out=sprintf("Folder %s already exists\n",$dirstore);
}
print $out; print $fo $out;

# copy MSA to directory dirstore
my $dmsa=sprintf("%s/%s", $dirstore, $msa);
unless(-e $dmsa){`cp $msa $dirstore`;}

# RaxML options
if($option && -e $option){`cp $option $dirstore`;}

# Define variables
my $file_RMSD=""; my $file_DE=""; my $file_summ_tnm="";
my $file_summ_Prot_evol="";
my $file_StabCPE=""; my $file_StrCPE=""; my $file_SSCPE="";
my $file_rate_StabCPE=""; my $file_rate_StrCPE=""; my $file_rate_SSCPE="";
my $StabCPE=""; my $StrCPE=""; my $SSCPE="";

chdir $dirstore;
my $workdir=Print_dir();
my $dir_tmp=sprintf("tmp_%s", $pdbcode);

# Check if TNM results exist, otherwise run TNM
if($reuse){
    print "Checking if TNM results exist in folder ",$workdir,"\n";
    Get_files_TNM($workdir);
}else{
    $out=sprintf("TNM and Prot_evol results not reused even if they exist\n");
    print $out; print $fo $out;
}
if($file_RMSD ne ""){
    $out=sprintf("TNM results exist in %s:\n", $workdir);
}else{
    # TNM results do not exist, run the tnm program
    $out=sprintf("TNM results do not exist, running tnm:\n");
    Run_TNM($pdb, $chain, $Mut_para);
}
print $out; print $fo $out;

$out=sprintf("%s\n%s\n%s\n\n", $file_RMSD, $file_DE, $file_summ_tnm);
print $out; print $fo $out;

if($reuse){
# Check if Prot_evol results exist, otherwise run Prot_evol
    $out=sprintf("Checking if Prot_evol results exist in %s\n", $workdir);
    print $out; print $fo $out;
    Get_files_Prot_evol($workdir);
}
if($file_SSCPE && $file_rate_SSCPE){
    # Prot_evol results exist, use them
    $out=sprintf("Prot_evol results exist in %s\n", $workdir);
    print $out; print $fo $out;
}else{
    # Prot-evol results do not exist, run the program
    $out=sprintf("Prot_evol results not found, running Prot_evol\n");
    print $out; print $fo $out;
    Run_Prot_evol($pdb, $chain, $msa_1);
}
my $file_model; my $file_rate_model;
if($model eq "STAB"){
    $file_model=$file_StabCPE; $file_rate_model=$file_rate_StabCPE;
}elsif($model eq "STRUCT"){
    $file_model=$file_StrCPE; $file_rate_model=$file_rate_StrCPE;
}else{
    $file_model=$file_SSCPE; $file_rate_model=$file_rate_SSCPE;
}

$out=sprintf("Prot_evol results:\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n\n",
	     $file_summ_Prot_evol, $file_SSCPE, $file_StrCPE, $file_StabCPE,
	     $file_rate_SSCPE, $file_rate_StrCPE, $file_rate_StabCPE);
print $out; print $fo $out;


$out=sprintf("Using Prot_evol results %s %s\n", $file_model,$file_rate_model);
print $out; print $fo $out;

# Clean Prot_evol and TNM results
if(-d $dir_tmp){
    `rm -rf $dir_tmp`;
    $out=sprintf("Deleting Prot_evol and TNM results in %s\n",$dir_tmp);
    print $out; print $fo $out;
}

# Count number of sites
open(my $fh, '<:encoding(UTF-8)', $file_model)
or die "Could not open file '$file_model' $!";
my $length=0;
while (my $row = <$fh>){if(substr($row,0,4) eq "SITE"){$length++;}}
close $fh;
$out=sprintf("%d amino-acid sites found in file %s\n",$length,$file_model);
print $out; print $fo $out;

# Convert format
my $msa_2=Remove_extension($msa_1);
$msa_2=sprintf("%s_1.fasta", $msa_2);
FastaManyLines_FastaOneLine($msa_1, $msa_2);
my $msa_3=Remove_extension($msa_1);
$msa_3=sprintf ("%s_Nogap.fasta", $msa_3);
my $naa_1=RemakeAlnsWithoutGapsFirstSeq($msa_2, $msa_3);
$out=sprintf("Made one line alignment without gaps %s\n", $msa_3);
print $out; print $fo $out;
`rm -f $msa_2`;

if($naa_1 != $length){
    $out=sprintf("ERROR, different number of sites in model %s (%d)",
		 "and in purged MSA %s (%d)\n",
		 $file_model, $length, $msa_3, $naa_1);
    print $out; print $fo $out;
    die;
}

for(my $i=1; $i<=$length; $i++){$rate[$i]=1;}
if($setrate){
    Read_rates($file_rate_model, $length);
    $out=sprintf("Site-specific rates read in %s ", $file_rate_model);
    if($setrate>0){$out=sprintf("%s BU_i=rate_i\n", $out);}
    else{$out=sprintf("%s BU_i=1/rate_i\n", $out);}
}else{
    $out=sprintf("Using uniform rate at each site\n");
}
print $out; print $fo $out;

#my $Prot_model=sprintf("%s_%s_rate%d", $prot, $model, $setrate);
$partition_file=sprintf("%s_%s.txt", $MyModel, $partition_file);
Make_partition($MyModel, $length, $partition_file);
MatricesFile_FromProtEvol_to_PAML($MyModel, $file_model, $length);

# Run RAxML-NG
my $command;
if($runraxml){
    my $msa=sprintf("%s.fasta", $MyModel);
    `cp $msa_3 $msa`;

    $out=sprintf("\nRunning RAxML-NG Input name: %s\n", $msa);
    print $out; print $fo $out;

    my $ntaxa=0;
    print "Reading $msa\n";
    open($fh, '<', $msa);
    while (my $row = <$fh>){if(substr($row, 0, 1) eq ">"){$ntaxa++;}}
    close $fh;
    my $branches=2*$ntaxa-3;
    $out=sprintf("%d taxa, %d branches, %d positions\n",
		 $ntaxa, $branches, $length);
    print $out; print $fo $out;
    
    my $raxmlopt="";
    if(-e $option){
	open(my $fh, '<:encoding(UTF-8)', $option);
	while ($raxmlopt = <$fh>){chomp($raxmlopt);}
	close $fh;
	$out=sprintf("Reading other RAxML options in %s, found:\n%s\n\n",
		     $option, $raxmlopt);
	print $out; print $fo $out;
    }

    my $command=
	"$raxmlng --search --msa $msa --model $partition_file --brlen scaled";
	#"$raxmlng --search --msa $msa --model $partition_file --brlen scaled --blopt nr_safe";
	#"$raxmlng --search --msa $msa --model $partition_file --brlen linked";
    if(1){	    
	my $nsite=120; # nsite sites per thread
    	if($thread<=0){
		$thread=int($length/$nsite);
	        if($thread*$nsite < $length){$thread++;}
        }
    	if($thread){$command=sprintf("%s --threads %d", $command, $thread);}
    }else{    
	$command=sprintf("%s --threads auto", $command);
    }
    if($raxmlopt){$command=sprintf("%s %s", $command, $raxmlopt);}
    system($command);

    print $command,"\n"; print $fo $command,"\n";


    #`$raxml --search --msa $msa_3 --model JTT +FC +G --opt-model off`;
    # For JTT

    if($clean){`rm -f $MyModel*_site_*.txt`;}

    my $raxmlout=sprintf("%s.raxml.log", $msa);
    if(-e $raxmlout){
	$out=sprintf("\nReading RAxML-NG results in %s\n", $raxmlout);
	print $out; print $fo $out;
	$fh=open(my $fh, '<', $raxmlout);
	my $LogLik=0;
	while (my $row = <$fh>){
	    if(substr($row, 0, 12) eq "Final LogLik"){
		@word=split(/ /, $row);
		$LogLik=$word[2]; last;
	    }
	}
	close $fh;
	$out=sprintf("LogLikelihood= %.3f /(n*branches): %.5g\n",
		     $LogLik, $LogLik/($length*$branches));
    }else{
	$out=sprintf("WARNING RAxML-NG results not found in %s\n",$raxmlout);
    }
    print $out; print $fo $out;
}
print "log information written in $nameout\n";
exit;

sub help{

    print "ERROR, PDB file and alignment file must be specified\n";
    print
	"USAGE: ",$0,,
	" -msa <MSA file> (FASTA)\n",
	" -pdb <PDB file>\n",
	" -chain <PDB chain> (default: first chain)\n",
	" -model <SSCPE STRUCT or STAB> (Prot_evol model, default: SSCPE)\n",
	" -raxml (run RAxML-NG)\n",
	" -option <one line file with other RAxML options> (optional)\n",
	" -thread (number of processors used by RAxML-NG)\n",
	" -rate <0,1,-1> 1: BU=site-spec subst.rate; 0: BU=1; -1: BU=1/rate\n",
	" -noreuse (Do not reuse TNM or Prot_evol results ",
	"even if they already exist)\n",
	" -noclean (Do not clean RAxML partitions after use)\n",
	"\n";
    die;
}

sub Get_file{ #($dirstore, ".tnm.summary.")
    my $tmp=`ls -1 $_[0]/*$_[1]*`; chomp($tmp);
    if(substr($tmp,0,3) eq "ls:"){return("");}
    my @word=split(/\//, $tmp); my $w=scalar(@word);
    #print "File: ",$tmp,"\n"; 
    #print $w; if($w>1){print " ", $word[$w-1];} print "\n";
    if($w>1){return($word[$w-1]);}
    else{return("");}
}

sub Make_partition{ # $MyModel $length, $partition_file

    my $model=$_[0]; my $length=$_[1]; my $output=$_[2];
    print "Making partitions for sites 1-",$length,
    ", output: ",$dirstore,"/",$output,"\n";
    open (my $fo,'>',$output);
    for (my $s=1; $s<=$length; $s++){
	my $b;
	if($setrate==0){$b=1;}
	elsif($setrate>0){$b=$rate[$s];}
	elsif($setrate<0){$b=1/$rate[$s];}
	my $out=sprintf("PROTGTR{%s_site_%d.txt}+BU{%.3g}, p%d = %d-%d\n",
			$model, $s, $b, $s, $s, $s);
	print $fo $out;
    }
    close $fo;
    return;
}

sub MatricesFile_FromProtEvol_to_PAML{ #$_[0]=$file_model $_[1]=$length
    print "Converting Matrix files From ProtEvol to PAML format\n";
    # Author: Miguel Arenas (2014, CBMSO, CSIC-UAM Madrid)"

# Loading input file with matrices from Prot_evol
    my $Model= $_[0]; my $file = $_[1]; my $length= $_[2];
    unless (open(FROM,$file)){
	print STDERR "Cannot open file \"$file\"\n\n"; die;
    }
    print "Matrices file uploaded: $file $length sites\n";	

    print "Writing one exchangeability matrix per site: ";
    my $WorkingSite=0;
    my $Site=0;
    my $Line=0;
    open(FROM, $file);
    while (<FROM>){
	#$Lines++;
	# Detect site
	if ($_ =~ /^SITE/){
	    my @seq1 = split(/\s+/, $_);
	    my $PDBSite = $seq1[1];
	    if ($Site){close (FILE_2);}
	    $Site++; print "$Site ";
	    my $createdFile = sprintf ("%s_site_%d.txt",$Model,$Site);
	    open (FILE_2,'>',$createdFile);
	    $Line=0;
	}else{
	    $Line++; 
	    if($Site && $Line<=22){print FILE_2 $_;}
	}	
    } # end of lines FROM
    print "\nModels have been written in $dirstore/$Model\_site_<n>.txt\n";
    print "Finished\n\n";

    close (FILE_2);
    close (FROM);
}

sub FastaManyLines_FastaOneLine{ #$_[0]=Input $_[1]=Output

    print "Converting MSA to one line format\n";

# opening lines of input files
    my $Input = $_[0];
    unless (open(FROM,$Input)){
	print STDERR "Cannot open file \"$Input\"\n\n";
    }

# Reading input file 
    print "Loading $Input\n";

    my $newfile_tree = $_[1];
    open (FILE_OUTPUT,">$newfile_tree");

    my $NumberSites = 0;
    my @AALong_SequenceHere1;
    my @AALong_HeadSeqHere1;

    my $SeqNumber = 0;    
    while (<FROM>){
	if ($_ =~ />/){
	    $SeqNumber++;
	    if ($SeqNumber > 1){print FILE_OUTPUT "\n";}
        
	    my $TaxaName = $_;
	    $TaxaName =~ s/\n//g; # remove the end of line
	    $TaxaName =~ s/\s//g; # remove blank site
	    $AALong_HeadSeqHere1[$SeqNumber] = $TaxaName;
            
	    print FILE_OUTPUT $_;   
        }else{
	    my $sequenceHere = $_;
	    $sequenceHere =~ s/\n//g; # remove the end of line
	    $sequenceHere =~ s/\s//g; # remove blank site
	    $NumberSites = length($sequenceHere);
	    $AALong_SequenceHere1[$SeqNumber] = $sequenceHere;
	    print FILE_OUTPUT "$sequenceHere";
        }		
    }
    print FILE_OUTPUT "\n";
    close (FROM);
    close (FILE_OUTPUT);
    print "Finished\n\n";
    return;
}
	
sub RemakeAlnsWithoutGapsFirstSeq_Ugo{

# It does not assume that the fasta file contains only one line per sequence
    my $AAFileName1=$_[0];
    print "Remaking alignment $_[0] without columns with gaps in first seq.\n";
    
# opening lines of input files
    unless (open(FROM,$AAFileName1)){
	print STDERR "Cannot open file \"$AAFileName1\"\n\n"; die;
    }

    my $newfile_ALN = $_[1];
    open (FILE_OUTPUT,">$newfile_ALN");

    my @gapPos;
    my $NumberGapsPos = 0;
    my $SeqNumber = 0;
    my $num_aa=0;
    open(FROM,$AAFileName1);
    while (<FROM>){ # for each line
	if ($_ =~ />/){
	    if($SeqNumber){print FILE_OUTPUT "\n";}
	    $SeqNumber++;
	    $num_aa=0;
	    print FILE_OUTPUT $_;
	}else{
# identify sites with gaps and print only the sequence without gaps
	    my $ThisSeq_1 = $_;
	    $ThisSeq_1 =~ s/\n//g; # remove the end of line
	    $ThisSeq_1 =~ s/\s//g; # remove blank site
	    my @AASeq = split ('', $ThisSeq_1);
	    if($SeqNumber==1){
		# Identify columns with gaps
		my $l=length($ThisSeq_1); $num_aa+=$l;
		for (my $AAn = 0; $AAn < $l; $AAn++){
		    if ($AASeq[$AAn] ne "-"){$gapPos[$AAn]=0;}
		    else{$gapPos[$AAn]=1; $NumberGapsPos++;}
		}
	    }
	    for (my $AAn = 0; $AAn < length($ThisSeq_1); $AAn++){
		if ($gapPos[$AAn]==0){		    
		    print FILE_OUTPUT "$AASeq[$AAn]";
                }
            }
        }

    }
    print FILE_OUTPUT "\n";

    # Print columns with gap
    print "Columns with gaps: ";
    for (my $n = 0; $n < $num_aa; $n++){
	if($gapPos[$n]){print "$n ";}
    }
    print "\n";
    close (FROM);
    close (FILE_OUTPUT);
    return $num_aa;
}

sub RemakeAlnsWithoutGapsFirstSeq{
# It assumes that the fasta file contains only one line per sequence

    my $AAFileName1=$_[0];
    print "Remaking alignment $_[0] without columns with gaps in first seq.\n";

    my $newfile_ALN = $_[1];
    open (FILE_OUTPUT,">$newfile_ALN");
    
# opening lines of input files
    unless (open(FROM,$AAFileName1)){
	print STDERR "Cannot open file \"$AAFileName1\"\n\n"; die;
    }

    my $col_number = -1;
    my $aa_number1=0;
    my $SeqNumber = 0;
    
    my @gapPos;
    my $NumberGapsPos = 0;
    my $counterLines=0;
    while (<FROM>){
	$counterLines++;
	if($_ =~ />/){
	    print FILE_OUTPUT $_; $SeqNumber++;
	}else{
	    my $ThisSeq_1 = $_;
	    $ThisSeq_1 =~ s/\n//g; # remove the end of line
	    $ThisSeq_1 =~ s/\s//g; # remove blank site
	    my @AASeq = split ('', $ThisSeq_1);

	    if($SeqNumber == 1){
		# identify columns with gaps and print only col without gaps
		$col_number = length($ThisSeq_1);
		print "Total number of columns: $col_number \n";
		
		for (my $AAn = 0; $AAn < $col_number; $AAn++){
		    if ($AASeq[$AAn] eq "-"){
			$NumberGapsPos++;
			$gapPos[$AAn] = 1;
		    }else{
			$gapPos[$AAn] = 0;
		    }
		}
		$aa_number1 = $col_number-$NumberGapsPos;
		print "Excluding gaps in first sequence: ", $aa_number1,"\n";
	    }
            
	    for (my $AAn = 0; $AAn < $col_number; $AAn++){
                if ($gapPos[$AAn] == 0){
		    print FILE_OUTPUT "$AASeq[$AAn]";
                }
            }
	    print FILE_OUTPUT "\n";
        }
    }

    close (FROM);
    close (FILE_OUTPUT);
    
    print "Columns with gaps: ";
    for (my $n = 0; $n < $col_number; $n++){
	if($gapPos[$n]){print "$n ";}
    }
    print "\n\n";
    return $aa_number1;
}


sub ModelsFromDATtoRAxMLng2{
### Programmer: Miguel Arenas Busto. March, 2019.
### Version 2.0 
###
    print "Converting to RAxML format\n";
    my @filesDat = <*.dat>;
    foreach my $file (@filesDat){ # for each .dat file
	my $newfile_rates = $file;
	$newfile_rates = sprintf ("%s.txt", $file);
	open (FILE_OUTPUT,">$newfile_rates");
	my @EntireFile = ();
	my $countLinesEntireFile = 0;
	my $line_position = 0;
	unless (open(FROM,$file)){
	    print STDERR "Cannot open file \"$file\"\n\n";
	}
	while (<FROM>){
	    $countLinesEntireFile++;
	    $EntireFile[$countLinesEntireFile] = $_;
	} 
	# now print the files
	for (my $n = 1; $n <= $countLinesEntireFile; $n++){
	    my $sequenceLineHere = $EntireFile[$n];
	    if ($n < 22){
		print FILE_OUTPUT $sequenceLineHere;
	    }
	}      
	close (FILE_OUTPUT);
	close (FROM);
    }
    #system ("rm *.dat");
    print "Finished\n\n";
    return;
}

sub Get_files_TNM{ #0=$dirstore
    my $dir=$_[0];
    $file_RMSD=Get_file($dir, "_RMSD.dat");
    $file_DE=  Get_file($dir, "_DE.dat");
    $file_summ_tnm=Get_file($dir, ".summary.");
}

sub Get_files_Prot_evol{ #0=$dirstore
    my $dir=$_[0];
    $SSCPE="RMSDWT";
    my $tmp=sprintf("_%s_exchangeability_sites", $SSCPE);
    $file_SSCPE=Get_file($dir, $tmp);
    if($file_SSCPE eq ""){
	$SSCPE="RMSDMF";
	$tmp=sprintf("_%s_exchangeability_sites", $SSCPE);
	$file_SSCPE=Get_file($dir, $tmp);
    }
    if($file_SSCPE eq ""){
	$SSCPE="DEWT";
	$tmp=sprintf("_%s_exchangeability_sites", $SSCPE);
	$file_SSCPE=Get_file($dir, $tmp);
    }
    if($file_SSCPE eq ""){
	$SSCPE="DEMF";
	$tmp=sprintf("_%s_exchangeability_sites", $SSCPE);
	$file_SSCPE=Get_file($dir, $tmp);
    }
    if($file_SSCPE eq ""){return;}

# Look for rate
    $tmp=sprintf("_%s_rate_profile", $SSCPE);
    $file_rate_SSCPE=Get_file($dir, $tmp);

    $StabCPE="WT";
    $tmp=sprintf("_%s_exchangeability_sites", $StabCPE);
    $file_StabCPE=Get_file($dir, $tmp);
    if($file_StabCPE eq ""){
	$StabCPE="MF";
	$tmp=sprintf("_%s_exchangeability_sites", $StabCPE);
	$file_StabCPE=Get_file($dir, $tmp);
    }
    $tmp=sprintf("_%s_rate_profile", $StabCPE);
    $file_rate_StabCPE=Get_file($dir, $tmp);

    $StrCPE="RMSD";
    $tmp=sprintf("_%s_exchangeability_sites", $StrCPE);
    $file_StrCPE=Get_file($dir, $tmp);
    if($file_StrCPE eq ""){
	$StrCPE="DE";
	$tmp=sprintf("_%s_exchangeability_sites", $StrCPE);
	$file_StrCPE=Get_file($dir, $tmp);
    }
    $tmp=sprintf("_%s_rate_profile", $StrCPE);
    $file_rate_StrCPE=Get_file($dir, $tmp);

    $file_summ_Prot_evol=Get_file($dir, "_summary.dat");
    return;
}

sub Run_Prot_evol{
    my $pdb=$_[0];
    my $chain=$_[1];
    my $msa_1=$_[2];

    unless(-e $Prot_evol){
	print "ERROR, wrong path to the program tnm $Prot_evol\n";
	print "Probably the folder name $dir_SSCPE in SSCPE.pl is wrong\n";
	print "Please try to rerun the installation script script_install_SSCPE.sh in the folder where you downloaded SSCPE.zip\n";
	die;
    }

    unless(-d $dir_tmp){
	`mkdir $dir_tmp`;
	$out=sprintf("Creating folder %s\n",$dir_tmp);
	print $out; print $fo $out;
    }
    chdir $dir_tmp;

    my $subdir=Print_dir();

    # Prepare configuration file for Prot_evol
    my $input=Write_input_Prot_evol($pdb, $msa_1, $chain, $pdbcode);
    my $command=sprintf("%s %s >> %s.Prot_evol.log\n",
			$Prot_evol, $input, $pdbcode);
    $out=sprintf("Running Prot_evol: %s", $command);
    print $out; print $fo $out;
    `$command`;
    print "Finished\n\n";

    # Store results of Prot_evol
    Get_files_Prot_evol(".");
    Move_files_Prot_evol("../");
    `mv $input ../`;

    chdir "..";
    $subdir=Print_dir();
    # Clean
    #`rm -rf $dir_tmp`; print "Deleting dir ",$dir_tmp,"\n";
}

sub Move_files_Prot_evol
{
    my $dir=$_[0];
    my $name=sprintf("%s%s", $pdbcode, $chain);
    if($file_SSCPE eq ""){
	print "ERROR, results for SSCPE not found for ",$name,"\n"; die;
    }else{
	`mv $file_SSCPE $dir`;
	`mv $file_rate_SSCPE $dir`;
    }
    if($file_StabCPE eq ""){
	print "WARNING, results for StabCPE not found for ",$name,"\n";
    }else{
	`mv $file_StabCPE $dir`;
	`mv $file_rate_StabCPE $dir`;
    }
    if($file_StrCPE eq ""){
	print "WARNING, results for StrCPE not found for ",$name,"\n";
    }else{
	`mv $file_StrCPE $dir`;
	`mv $file_rate_StrCPE $dir`;
    }
    my $file_tmp=Get_file(".", "summary.dat");
    if($file_tmp eq ""){
	print "WARNING, summary of Prot_evol not found for ",$name,"\n";
    }else{
	my $prot=substr($file_SSCPE,0,5);
	$file_summ_Prot_evol=sprintf("%s_Prot_evol_summary.dat",$prot);
	`mv $file_tmp $dir/$file_summ_Prot_evol`;
    }
}

sub Run_TNM{ 

    my $pdb=$_[0];
    my $chain=$_[1];
    my $Mut_para=$_[2];

    unless(-e $tnm){
	print "ERROR, wrong path to the program tnm $tnm\n";
	print "Probably the folder name $dir_SSCPE in SSCPE.pl is wrong\n";
	print "Please try to rerun the installation script script_install_SSCPE.sh in the folder where you downloaded SSCPE.zip\n";
	die;
    }
    unless(-e $Mut_para){
	print "ERROR, wrong path to the mutation parameters $Mut_para\n";
	print "Probably the folder name $dir_SSCPE in SSCPE.pl is wrong\n";
	print "Please try to rerun the installation script script_install_SSCPE.sh in the folder where you downloaded SSCPE.zip\n";
	die;
    }



    unless(-d $dir_tmp){
	`mkdir $dir_tmp`;  print "Creating folder ",$dir_tmp,"\n";
    }
    chdir $dir_tmp;
    Print_dir();

    # Prepare configuration file for TNM
    my $input=Write_input_TNM($pdb, $chain, $Mut_para);
    my $command=sprintf("%s %s > %s.tnm.log\n", $tnm, $input, $pdbcode);
    $out=sprintf("Running TNM: %s", $command);
    print $out; print $fo $out;
    `$command`; # run the tnm program
    $out="Finished\n";
    print $out; print $fo $out;

    # Store TNM results
    my $name=substr(`ls -1 *summary.dat`,0,5);
    if(substr($name,0,3) eq "ls:"){
	print "ERROR, TNM program could not be run\n"; die;
    }else{
	print "TNM executed for protein chain ",$name,"\n";
    }
    $file_RMSD=sprintf("%s.mut_RMSD.dat",$name);
    $file_DE=sprintf("%s.mut_DE.dat",$name);
    my $file_tmp=sprintf("%s.summary.dat",$name);
    $file_summ_tnm=sprintf("%s.tnm.summary.dat",$name);
    `mv $file_RMSD ../`;
    `mv $file_DE ../`;
    `mv $file_tmp ../$file_summ_tnm`;
    `mv $input ../`;

    chdir "..";
    Print_dir();
}

sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out=sprintf("%s.%s",$out,$word[$i]);
    }
    return $out;
}

sub Read_rates{ #($file_rate_SSCPE, $length)
    print "Reading $_[0]\n";
    open(my $fh, '<:encoding(UTF-8)', $_[0])
	or die "Could not open file '$_[0]' $!";
    my $s=1;
    while (my $row = <$fh>){
	if(substr($row, 0, 1) eq "#"){next;}
	my @word=split(/\s+/, $row); my $w=scalar(@word);
	$rate[$s]=$word[$w-1]; $s++; 
    }
    $s--; print "$s rates read\n";
    close $fh;
}

sub Write_input_Prot_evol{ #($pdb, $msa_1, $chain, $pdbcode)  
    my $pdb=$_[0];
    my $msa_1=$_[1];
    my $chain=$_[2];
    my $pdbcode=$_[3];

    my $input=sprintf("Input_Prot_evol_%s.in", $pdbcode);
    open(my $fo, '>', $input);
    print $fo "ALI= ../",$msa_1,"\n";
    print $fo "PDB= ",$pdb,"\n";
    if($chain){print $fo "CHAIN= ",$chain,"\n";}
    if($file_RMSD){print $fo "STR_MUT= ../",$file_RMSD,"\n";}
    if($file_DE){print $fo "STR_MUT= ../",$file_DE,"\n";}
    print $fo "MF_COMP=0\n";
    print $fo "MATRIX=OPT\n";
    print $fo "EXCHANGE=FLUX\n";
    print $fo "MEANFIELD= 1\n";
    print $fo "PRINT_E=1\n";
    print $fo "OPT_REG= 1\n";
    print $fo "SCORE_CV= 0\n";
    print $fo "REG=0.05\n";
    print $fo "REMUT=1\n";
    print $fo "GET_FREQ=3\n";
    print $fo "FILE_STR= ",$dir_SSCPE,"/structures.in\n";
    print $fo "A_LOC= 1            # Use secondary structure propensities?\n";
    print $fo "TEMP=  1.0	   # Temperature\n";
    print $fo "SU1=   0.13	   # config. entropy per res (unfold)\n";
    print $fo "SC1=  0.065	   # config. entropy per res (misfold)\n";
    print $fo "SC0=  0.0	   # config. entropy offset (misfold)\n";
    print $fo "REM=   2	           # Use 0,1,2 moments of misfolding energy\n";
    close $fo;
    return($input);
}

sub Write_input_TNM{ #($pdb, $chain, $Mut_para)

    my $pdb=$_[0];
    my $chain=$_[1];
    my $Mut_para=$_[2];

    my $input=sprintf("Input_TNM_%s.in", $pdbcode);
    open(my $fo, '>', $input);
    print $fo "PDB1= ",$pdb,"\n";
    if($chain){print $fo "CH1= ",$chain,"\n";}
    print $fo "FIT_B=1           ! Fit force constant from B factors\n";
    print $fo "PRED_MUT=1        ! Predict RMSD of all possible mutations\n";
    print $fo "MUT_PARA=",$Mut_para,"   ! File with mutation parameters\n";
    close $fo;
    return($input);
}

sub Print_dir{
    my $dir=`pwd`; chomp($dir);
    my $out=sprintf("Working directory: %s\n", $dir);
    print $out; print $fo $out;
    return($dir);
}
