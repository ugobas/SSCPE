#!/usr/bin/env perl 
use strict;
use warnings;
use Getopt::Long;
use Cwd qw(getcwd);
use File::Copy;
use File::Basename;
use Config;

my @iwts=(0,3,5,7,10,20);
my @fluxes=(0,1);
my @Halpern=(0,1);
my @rates=(0,1);
my @MODELS=("LG","WAG","JTT",   # Empirical
	    "MF","WT",    # STAB "DDG",
	    "DE","RMSD",  # STRUCT
	    "DEWT","RMSDWT", # SSCPE
	    "DEMF","RMSDMF"); # $allmut==1
my @vars=("iwt","HB","FL","rate");
my $nvar=scalar(@vars);

my @files=`ls -1 Diff*txt`;
my $nfile=scalar(@files);
my @KS1; my @KS2; my @RF; my @LogLik; my @read;
my @Kv1; my @Kv21; my @Kv22; my @ranked;
my @support;
for(my $i=0; $i<$nfile; $i++){
    chomp $files[$i];
    $KS1[$i]=0; $KS2[$i]=0; $RF[$i]=0;
    $KS1[$i]=0; $KS2[$i]=0; 
    $Kv1[$i]=0; $Kv21[$i]=0; $Kv22[$i]=0; 
    $LogLik[$i]=0;
    $read[$i]=0;
    $support[$i]=0;
    $ranked[$i]=0;
}
for(my $i=0; $i<$nfile; $i++){
    my $file=$files[$i];
    print "file= $file\n";
    Read_KS($file, $i);
    $LogLik[$i]=Read_Log($file);
}
my $nameout="Summary_Diff_ranked.dat";
open (my $fo, ">", $nameout);
print "Writing ranked files in $nameout\n";
print $fo "#1=rank 2=KScore_1 3=KScore_2 4=RF 5=LogLik ".
    "6=Kval_1 7=Kval_21 8=Kval_22 9=support 10=file\n";
for(my $rank=0; $rank<$nfile; $rank++){
    my $j=-1;
    for(my $i=0; $i<$nfile; $i++){
	if($read[$i]==0 || $ranked[$i]){next;}
	if($j<0 || $KS2[$i]<$KS2[$j]){$j=$i;}
    }
    if($j<0){last;}
    $ranked[$j]=1;
    my $ll=sprintf("%.0f", $LogLik[$j]);
    print $fo "$rank\t$KS1[$j]\t$KS2[$j]\t$RF[$j]\t$ll".
	"\t$Kv1[$j]\t$Kv21[$j]\t$Kv22[$j]\t$support[$j]".
	"\t$files[$j]\n";
}
close $fo;


my @diff1_KS; my @diff2_KS; my @ndiff;
my @diff1_K2; my @diff2_K2;
for(my $i=0; $i<$nvar; $i++){
    $diff1_KS[$i]=0;
    $diff2_KS[$i]=0;
    $ndiff[$i]=0;
    $diff1_K2[$i]=0;
    $diff2_K2[$i]=0;
}

for(my $i=0; $i<$nfile; $i++){
    my $file=$files[$i];
    print "file= $file\n";
    if($read[$i]<0){next;}
    for(my $s=0; $s<length($file); $s++){
	if(substr($file,$s,1) eq "\." || substr($file,$s,1) eq "_"){
	    $s++;
	    my $ivar=-1; my $l=0; 
	    if(substr($file,$s,3) eq "iwt"){$ivar=0; $l=3;}
	    elsif(substr($file,$s,2) eq "HB"){$ivar=1; $l=2;}
	    elsif(substr($file,$s,2) eq "FL"){$ivar=2; $l=2;}
	    elsif(substr($file,$s,4) eq "rate"){$ivar=3; $l=4;}
	    if($ivar>=0){
		$s+=$l;
		my $x=substr($file,$s,1);
		my $y="\0";
		if($x eq "0"){$y="1";}
		elsif($x eq "1"){if($ivar){$y="0";}else{$y="3";}}
		elsif($x eq "3"){$y="5";}
		elsif($x eq "5"){$y="7";}
		elsif($x eq "7"){$y="5";}
		else{
		    print "WARNING in $file unexpected value $x\n";
		    next;
		}
		my $file2=$file;
		substr($file2,$s,1)=$y;
		my $k=-1;
		for(my $j=0; $j<$nfile; $j++){
		    if($file2 eq $files[$j]){$k=$j; last;}
		}
		if($k<0){
		    print "WARNING, pair of $file = $file2 not found\n";
		    next;
		}elsif($k<$i){next;}
		if($read[$k]<0){next;}

		# Difference between the two files
		print "Comparing $file $file2\n";
		my $diff_KS=$KS1[$i]-$KS1[$k];
		my $diff_K2=$KS2[$i]-$KS2[$k]; 
		if($y>$x){$diff_KS=-$diff_KS; $diff_K2=-$diff_K2;} 
		$diff1_KS[$ivar]+=$diff_KS;
		$diff2_KS[$ivar]+=$diff_KS*$diff_KS;
		$diff1_K2[$ivar]+=$diff_K2;
		$diff2_K2[$ivar]+=$diff_K2*$diff_K2;
		$ndiff[$ivar]++;
	    }

	}

    }
}

print "Printing ranked K score in $nameout\n";
$nameout="Summary_Diff.txt";
print "Printing results in $nameout\n";
open($fo, ">", $nameout);
print $fo "#Variable values diff_KS SEM diff_K2 SEM n\n"; 
for(my $i=0; $i<$nvar; $i++){
    my $out=$vars[$i];
    if($vars[$i] eq "iwt"){$out=$out." ${iwts[1]}-${iwts[0]}";}
    else{$out=$out." 1-0";}
    if($ndiff[$i]==0){$out=$out."No_data\n";}
    else{
	$diff1_KS[$i]/=$ndiff[$i];
	$diff1_K2[$i]/=$ndiff[$i];
	if($ndiff[$i] > 1){
	    $diff2_KS[$i]=$diff2_KS[$i]/$ndiff[$i]-$diff1_KS[$i]*$diff1_KS[$i];
	    $diff2_KS[$i]=sqrt($diff2_KS[$i]/($ndiff[$i]-1));
	    $diff2_K2[$i]=$diff2_K2[$i]/$ndiff[$i]-$diff1_K2[$i]*$diff1_K2[$i];
	    $diff2_K2[$i]=sqrt($diff2_K2[$i]/($ndiff[$i]-1));
	}else{
	    $diff2_KS[$i]=$diff1_KS[$i];
	    $diff2_K2[$i]=$diff1_K2[$i];
	}
	my $res=sprintf(" %.3g %.2g %.3g %.2g %d\n",
			$diff1_KS[$i], $diff2_KS[$i],
			$diff1_K2[$i], $diff2_K2[$i],$ndiff[$i]);
	print $fo $out, $res;
    }
}
close $fo;

sub Read_KS{
    my ($file, $i) = @_;
   if(!-e $file){
	print "WARNING, $file does not exist\n";;
    }
    open(my $fh, "<", $file);
    my $l=0;
    while (my $row = <$fh>){
	if(substr($row, 0, 4) eq "Tree"){next;}
	my @word = split(/\s+/, $row);
	if(scalar(@word) != 11){
	    print "ERROR, 11 records expected in ${file}, found ",
	    scalar(@word),"\n"; last;
	}
	$read[$i]=1;
	$KS1[$i]= $word[4];
	$Kv1[$i]= $word[5];
	$KS2[$i]= $word[6];
	$Kv21[$i]= $word[7];
	$Kv22[$i]= $word[8];
	$RF[$i]=$word[9];
	$support[$i]=$word[10];
	print "KS = $KS1[$i] K2= $KS2[$i]\n";
	last;
    }
    close $fh;
}

sub Read_Log{
    my ($file, $i)=@_;
    my @word = split(/\./, $file);
    my $new_name="$word[1]*.$word[2].$word[3]";
    my $nword=1;
    if(scalar(@word)>5){$new_name=$new_name.".$word[4].$word[5]";}
    else{$nword=2;}
    my @file2 = `ls -1 *${new_name}*.log`;
    if(scalar(@file2)!= 1){
	print "ERROR, there are ".scalar(@file2)." files *${new_name}*.log:\n";
	foreach my $f (@file2){print $f;}
	return(0);
    }
    chomp $file2[0];
    print "File: $file2[0]\n";
    if(!-e $file2[0]){
	print "ERROR, file $file2[0] does not exist\n"; return(0);
    }
    my $string=`grep LogLik $file2[0]`;

    @word=split(/\s+/, $string);
    print "Loglik= $word[$nword]\n";
    #if(scalar(@word)<2){return(0);}
    return($word[$nword]);
}
