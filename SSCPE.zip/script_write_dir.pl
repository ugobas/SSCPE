#!/usr/bin/env perl 
use strict;
use warnings;
my $SSCPE="SSCPE.pl";
my $Input_TNM="Input_TNM.in";
my $Input_Prot_evol="Input_Prot_evol.in";

my $dir=`pwd`; chomp ($dir);
print "Working directory: ",$dir,"\n";

# Write directory in SSCPE.pl
my $modified=0;
my $tmp="tmp.out";
open(my $fo, '>', $tmp);
my $file=$SSCPE;
open(my $fh, '<:encoding(UTF-8)', $file)
or die "Could not open file '$file' $!";
my $string="my \$dir_SSCPE=";
while (my $row = <$fh>){
    if(substr($row, 0, 14) eq $string){
	print $fo "my \$dir_SSCPE=\"",$dir,"\";\n";
	$modified=1;
    }else{
	print $fo $row;
    }
}
close $fh;
close $fo;
if($modified){
    `mv -f $tmp $file`;
    print "$file was modified\n";
}else{
    print "WARNING, $file, was not modified\n";
}
`chmod u+x $file`;


# Modify input of TNM
$file=$Input_TNM;
$modified=0;
open($fh, '<:encoding(UTF-8)', $file)
or die "Could not open file '$file' $!";
open($fo, '>', $tmp);
while (my $row = <$fh>){
    if(substr($row, 0, 8) eq "MUT_PARA"){
	print $fo "MUT_PARA=",$dir,"/Mutation_para.in\n";
	$modified=1;
    }else{
	print $fo $row;
    }
}
close $fh;
close $fo;
if($modified){
    `mv -f $tmp $file`;
    print "$file was modified\n";
}else{
    print "WARNING, $file was not modified\n";
}

# Modify input of Prot_evol
$file=$Input_Prot_evol;
$modified=0;
open($fh, '<:encoding(UTF-8)', $file)
or die "Could not open file '$file' $!";
open($fo, '>', $tmp);
while (my $row = <$fh>){
    if(substr($row, 0, 4) eq "PDB=" ||
       substr($row, 0, 4) eq "ALI=" ||
       substr($row, 0, 8) eq "STR_MUT="){
	print $fo "#",$row;
    }elsif(substr($row, 0, 8) eq "FILE_STR"){
	print $fo "FILE_STR=",$dir,"/Mutation_para.in\n";
	$modified=1;
    }else{
	print $fo $row;
    }
}
close $fh;
close $fo;
if($modified){
    `mv -f $tmp $file`;
    print "$file was modified\n";
}else{
    print "WARNING, $file was not modified\n";
}
print "All done\n";
