#!/usr/bin/env perl 
use strict;
use warnings;
my $SSCPE="SSCPE_tree_RAxML.pl";
my $Input_TNM="Input_TNM.in";
my $Input_Prot_evol="Input_TNM.in";

my $dir=$ARGV[0];
if($dir eq ""){
    print "ERROR in ",$0," working directory not given\n";
}
unless(-d $dir){
    print "ERROR in ",$0," directory ",$dir," does not exist\n";
}
print "script: ",$0,"\n";
chdir $dir;

my $dir_now=`pwd`; print "Working directory: ",$dir_now;
chomp($dir_now); 

# Modify script
my $tmp="tmp.out";
my $file=$SSCPE;
my $modified=0;
open(my $fh, '<:encoding(UTF-8)', $file)
or die "Could not open file '$file' $!";
open(my $fo, '>', $tmp);
while (my $row = <$fh>){
    if(substr($row, 0, 17) eq "my \$dir_Prot_evol"){
	print $fo "my \$dir_Prot_evol=\"",$dir_now,"\";\n";
    }else{
	print $fo $row;
    }
}
close $fh;
close $fo;
`mv -f $tmp $file`;
`chmod u+x $file`;
print $file, " modified\n";

# Modify input of TNM
$file=$Input_TNM;
open($fh, '<:encoding(UTF-8)', $file)
or die "Could not open file '$file' $!";
open($fo, '>', $tmp);
while (my $row = <$fh>){
    if(substr($row, 0, 8) eq "MUT_PARA"){
	print $fo "MUT_PARA=",$dir_now,"/Mutation_para.in\n";
    }else{
	print $fo $row;
    }
}
close $fh;
close $fo;
`mv -f $tmp $file`;
print $file, " modified\n";

# Modify input of Prot_evol
$file=$Input_Prot_evol;
open($fh, '<:encoding(UTF-8)', $file)
or die "Could not open file '$file' $!";
open($fo, '>', $tmp);
while (my $row = <$fh>){
    if(substr($row, 0, 4) eq "PDB=" ||
       substr($row, 0, 4) eq "ALI=" ||
       substr($row, 0, 8) eq "STR_MUT="){
	print $fo "#",$row;
    }elsif(substr($row, 0, 8) eq "FILE_STR"){
	print $fo "FILE_STR=",$dir_now,"/Mutation_para.in\n";
    }else{
	print $fo $row;
    }
}
close $fh;
close $fo;
`mv -f $tmp $file`;
print $file, " modified\n";
print "All done\n";
