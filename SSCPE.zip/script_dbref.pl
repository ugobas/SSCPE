#!/usr/bin/env perl 
use strict;
use warnings;
use Getopt::Long;
use Cwd qw(getcwd);

my $pdbdir="";
my $ali="";
my $tree="";
my $EC=0;
my $mol=0;

# Input arguments
if(scalar(@ARGV)<2){help();}
#chomp($ARGV[scalar(@ARGV)-1]);
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-ali"){
	$i++; $ali=$ARGV[$i];
    }elsif($ARGV[$i] eq "-pdbdir"){
	$i++; $pdbdir=$ARGV[$i];
   }elsif($ARGV[$i] eq "-tree"){
	$i++; $tree=$ARGV[$i];
   }elsif($ARGV[$i] eq "-EC"){
       $EC=1;
   }elsif($ARGV[$i] eq "-mol"){
       $mol=1;
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
if($ali eq "" && $tree eq ""){help();}
if($ali && $tree ){help();}

my $input;
if($tree){$input=$tree;}
else{$input=$ali;}
my $new=$input.".dbref";

open(my $fo, '>', $new);
open(my $fh, '<', $input);

if($ali){
    while (my $row = <$fh>){
	if(substr($row, 0, 1) eq ">"){
	    chomp $row;
	    my $prot=substr($row, 1);
	    my $dbref=Attach_dbref($prot);
	    print $fo ">$dbref\n";
	}else{
	    print $fo $row;
	}
    }
}else{

    my $row = <$fh>; chomp $row;
    my $name; my $open=0; my $l=0; my $cname=0; my $out;
    for(my $i=0; $i<length($row); $i++){
	my $read=0;
	if(substr($row, $i, 1) eq "("){
	    $open=1; $cname=0; $name="";
	}elsif(substr($row, $i, 1) eq ","){
	    if($open){
		if($cname){Copy_dbref($out, $l, $name);}
		$open=0;
	    }else{
		$open=1;
	    }
	    $cname=0; $name="";
	}elsif(substr($row, $i, 1) eq ")"){
	    if($cname){Copy_dbref($out, $l, $name);}
	    $open=0; $cname=0; $name="";
	}elsif(substr($row, $i, 1) eq ":"){
	    if($cname){Copy_dbref($out, $l, $name);}
	    $open=0; $cname=0; $name="";
	}elsif($open){
	    $read=1;
	}
	#print substr($row, $i, 1)," open=$open read=$read cname= $cname\n";
	if($read){
	    substr($name, $cname, 1)=substr($row, $i, 1); $cname++;
	}else{
	    substr($out, $l, 1)=substr($row, $i, 1); $l++;
	}
    }
    print $fo $out;
}
close $fh; close $fo;
print "Writing names with dbref in $new\n";

sub Copy_dbref{
    my ($out, $l, $name) = @_;
    my $newname=Attach_dbref($name);
    print "name= $name newname= $newname\n";
    for(my $i=0; $i<length($newname); $i++){
	substr($_[0], $l, 1)=substr($newname, $i, 1); $l++;
    }
    $_[1]=$l;
}


sub Attach_dbref{
    my $prot=$_[0];
    if(length($_[0])!=5){
	print "WARNING, $_[0] is not a PDB code\n"; return;
    }
    my $pdbcode=substr($_[0], 0, 4);
    my $chain=  substr($_[0], 4, 1);
    my $pdbchain=uc($pdbcode);
    $pdbchain=$pdbchain." $chain";
    my $pdbfile=$pdbdir."/".$pdbcode.".pdb";
    my $command;
    my $dbref="";
    if($EC){
	$command="grep EC: $pdbfile\n";
	print $command;
	my @list=`$command`;
	my $n=0;
	my $record="NULL";
	foreach my $db (@list){
	    print $db;
	    my @word=split(/\s+/, $db);
	    my @w=split(/;/, $word[3]);
	    $record=$w[0];
	    $n++;
	}
	$dbref=$dbref.$record."_";
	if($n!=1){print "WARNING, $n records EC found in $pdbfile\n";}
    }
    if($mol){
	$command="grep COMPND $pdbfile | grep MOLECULE\n";
	print $command;
	my @list=`$command`;
	my $n=0;
	my $record="NULL";
	foreach my $db (@list){
	    print $db;
	    my @word=split(/\s+/, $db);
	    my $m=scalar(@word);
	    if($m<3){next;} $m--;
	    $record="";
	    for(my $j=3; $j<$m; $j++){$record=$record.$word[$j]."_";}
	    my @w=split(/;/,$word[$m]);
	    $record=$record.$w[0];
	    $n++;
	}
	if($n!=1){print "WARNING, $n records EC found in $pdbfile\n";}
	$dbref=$dbref.$record."_";
    }

    $command="grep DBREF $pdbfile | grep \"$pdbchain\"\n";
    print $command;
    my @list=`$command`;
    my $n=0;
    my $record="NULL";
    foreach my $db (@list){
	print $db;
	my @word=split(/\s+/, $db);
	if($word[5] eq "PDB"){next;}
	elsif($word[7] ne ""){$record=$word[7];}
	else{$record=$word[6];}
	$n++;
    }
    if($n!=1){print "WARNING, $n records dbref found in $pdbfile\n";}
    $dbref=$dbref.$record."_".$prot;
    print $dbref,"\n";
    return($dbref);
}

# grep DBREF $PDB/2bwj.pdb | grep "2BWJ A"
#DBREF  2BWJ A    0     0  PDB    2BWJ     2BWJ             0      0
#DBREF  2BWJ A    1   197  UNP    Q9Y6K8   KAD5_HUMAN     340    536

sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}

sub help{

    print "ERROR, ali or tree must be specified\n";
    print
	"USAGE: $0 \n",
	" -ali <MSA file> (FASTA) or\n",
	" -tree <tree in Newick format> line: pddbcode chain\n",
	" -pdbdir <Path to PDB>\n",
	" -EC  ! look for EC number besides DBREF\n",
	" -mol ! look for molecule besides DBREF\n\n",
	"Example:\n",
	"$0 -pdbdir /ngs/databases/pdb -ali Ploop.PCAli.fas\n";
    die;
}
