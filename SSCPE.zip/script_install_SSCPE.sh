#!/bin/sh

unzip *.zip


PROG="SSCPE.pl"

RAXML="raxml-ng"
chmod u+x $RAXML

echo "Directory where $PROG is installed: "
pwd

# Compile the TNM program
echo "Compiling tnm in folder DIR_TNM and moving to "
pwd

mkdir DIR_TNM
mv tnm.zip DIR_TNM
cd DIR_TNM
unzip tnm.zip
make
rm -f *.o
mv tnm ../
cp Mutation_para.in ../
cp Input_TNM.in  ../
cd ..

# Compile the Prot_evol program
echo "Compiling Prot_evol in folder DIR_PROT_EVOL and moving to current folder"
mkdir DIR_PROT_EVOL
mv Prot_evol.zip DIR_PROT_EVOL
cd DIR_PROT_EVOL
unzip Prot_evol.zip
make
rm -f *.o
mv Prot_evol ../
cp structures.in ../
cp Input_Prot_evol.in  ../
cd ..

echo "Assigning dependencies of $PROG"
chmod u+x $PROG
chmod u+x script_write_dir.pl
echo "Running the program script_write_dir.pl"
./script_write_dir.pl ./

echo "Executable file $PROG is in folder: "
pwd

