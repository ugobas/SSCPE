#!/bin/sh

DIR="BIN"
PROG="SSCPE_tree_RAxML.pl"
RAXML="raxml-ng"

unzip *.zip

mkdir $DIR
echo "Creating folder $DIR"

chmod u+x $RAXML
mv $RAXML $DIR

# Compile the TNM program
echo "Compiling tnm in folder TNM and moving to $DIR"
mkdir TNM
mv tnm.zip TNM
cd TNM
unzip tnm.zip
make
rm -f *.o
mv tnm ../$DIR
cp Mutation_para.in ../$DIR
cp Input_TNM.in  ../$DIR
cd ..

# Compile the Prot_evol program
echo "Compiling Prot_evol in folder PROT_EVOL and moving to $DIR"
mkdir PROT_EVOL
mv Prot_evol.zip PROT_EVOL
cd PROT_EVOL
unzip Prot_evol.zip
make
rm -f *.o
mv Prot_evol ../$DIR
cp structures.in ../$DIR
cp Input_Prot_evol.in  ../$DIR
cd ..

echo "Moving $PROG to folder $DIR and assigning its dependencies"
chmod u+x $PROG
mv $PROG $DIR
chmod u+x script_write_dir.pl
echo "Running the program script_write_dir.pl in $DIR"
./script_write_dir.pl $DIR

echo "Executable file $PROG is in folder $DIR"

