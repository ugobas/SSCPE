#!/bin/sh

unzip *.zip


PROG="SSCPE.pl"

RAXML="raxml-ng"
chmod u+x $RAXML

echo "Directory where $PROG is installed: "
pwd

# Compile the TNM program
echo "Compiling tnm in folder TNM and moving to "
pwd

mkdir TNM
mv tnm.zip TNM
cd TNM
unzip tnm.zip
make
rm -f *.o
mv tnm ../
cp Mutation_para.in ../
cp Input_TNM.in  ../
cd ..

# Compile the Prot_evol program
echo "Compiling Prot_evol in folder PROT_EVOL and moving to current folder"
mkdir PROT_EVOL
mv Prot_evol.zip PROT_EVOL
cd PROT_EVOL
unzip Prot_evol.zip
make
rm -f *.o
mv Prot_evol ../
cp structures.in ../
cp Input_Prot_evol.in  ../
cd ..

echo "Assigning dependencies of $PROG"
chmod u+x $PROG
chmod u+x script_write_dir.pl
echo "Running the program script_write_dir.pl"
./script_write_dir.pl ./

echo "Executable file $PROG is in folder: "
pwd

