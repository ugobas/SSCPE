#!/usr/bin/env perl 
use strict;
use warnings;
use Getopt::Long;
use Cwd qw(getcwd);
use File::Copy;
use File::Basename;
use Config;

my $norun=0;
my $run="qsubmit.pl -q x86_64 --mem 4 -s";


my @iwts=(3,5,7,10,20); #(5,10,20);
my @fluxes=(0,1);
my @Halpern=(0,1);
my @rates=(0,1);
my @MODELS=("LG","WAG","JTT",   # Empirical
	    "MF",
	    "WT",    # STAB "DDG",
	    "DE","RMSD",  # STRUCT
	    "DEWT",
	    "RMSDWT", # SSCPE
	    "DEMF","RMSDMF"
	   ); # $allmut==1

my $wmodel="DE"; # First model for whicih iwt is relevant
my $smodel="MF";

my $dir_SSCPE="/data/ubastolla/BIN/SSCPE";
my $Prog_SSCPE="${dir_SSCPE}/SSCPE.pl";
my $Prog_K2="${dir_SSCPE}/k2_mat.pl";
my $Prog_raxml="${dir_SSCPE}/raxml-ng";


my $pdbdir="";
my $pdblist="";

my $supfam="";
my $ref_tree="";
my $msa="";
my $pdb="";
my $chain="";

print "Script $0 author ",
    "Ugo Bastolla <ubastolla\@cbm.csic.es>\n",
    "It needs an input MSA (-ali), a pdb file either list (-pdblist -pdbdir) ",
    "or single (-pdb -chain) and reference tree (-tree).\n",
    "It runs the program SSCPE.pl, which generates site-specific ",
    "folding-stability and structure constrained substitution models ",
    "and adopts them for inferring a phylogenetic tree with RAxML-NG ",
    "and compares the inferred tree with the reference tree with k2_mat.pl ",
    "for all models and different options\n\n";

# Input arguments
if(scalar(@ARGV)<2){help();}
chomp($ARGV[scalar(@ARGV)-1]);
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-ali"){
	$i++; $msa=$ARGV[$i];
    }elsif($ARGV[$i] eq "-pdbdir"){
	$i++; $pdbdir=$ARGV[$i];
   }elsif($ARGV[$i] eq "-pdblist"){
	$i++; $pdblist=$ARGV[$i];
   }elsif($ARGV[$i] eq "-pdb"){
	$i++; $pdb=$ARGV[$i];
    }elsif($ARGV[$i] eq "-chain"){
	$i++; $chain=$ARGV[$i];
    }elsif($ARGV[$i] eq "-tree"){
	$i++; $ref_tree=$ARGV[$i];
    }elsif($ARGV[$i] eq "-norun"){
	$norun=1;
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
if($pdb eq "" && $pdblist eq ""){
    print "ERROR, PDB file(s) must be provided with option -pdb or -pdblist\n";
    help();
}
if($msa eq ""){
    print "ERROR, alignment file must be provided with option -ali <file>\n";
    help();
}
my @word=split(/\./, $msa);
$supfam=$word[0];
print "Superfamily $supfam\n";

my $name;
if($pdb){
    if($chain eq ""){$chain="A";}
    @word=split(/\//, $pdb);
    my $prot=Remove_extension($word[scalar(@word)-1]);
    $name="${prot}${chain}";
}else{
    @word=split(/\//, $pdblist);
    $name=Remove_extension($word[scalar(@word)-1]);
}

my $name_all; my $f_all; my $ini_all=0;
if($norun){
    $name_all="Results_".$supfam.".txt";
    open($f_all, '>', $name_all);
    print "Writing all results in $name_all\n";
    print $f_all "#1=model 2=LogLik 3=KS1 4=KS2 5=RF 6=Kv1 7=Kv21 8=Kv22\n";
    sleep 2;
}
my $nmod=0;  my $iw=0; 
foreach my $iwt (@iwts){
    $iw++; my $imod=0; my $wmod=0;
    foreach my $model (@MODELS){
	$imod++; my $kmod=0;
	if($model eq $wmodel){$wmod=1;}
	#if($imod<4){next;}
	if($wmod==0 && $iw > 1){next;}
	print "Model $model $imod\n";
	my $SSCPE=1; $kmod=0; 
	if($model eq "LG" || $model eq "WAG" || $model eq "JTT"){
	    $SSCPE=0;
	    for(my $gamma=0; $gamma<=1; $gamma++){
		print "kmod= $kmod nmod= $nmod\n";
		my $label="${model}_G${gamma}";
		my $command="--model $model";
		my $msa_new="${msa}_${label}";
		if($gamma){$command="${command}+G4"};
		if($norun){
		    my $name_log=$msa_new.".raxml.log";
		    Examine_tree($command, $label, $msa_new, $name_log);
		}else{
		    Run_model($SSCPE, $command, $label, $msa_new);
		}
		$kmod++; $nmod++;
	    }
	    next;
	} 
	# SSCPE model
	foreach my $HB (@Halpern){
	    foreach my $rate(@rates){
		foreach my $flux (@fluxes){
		    print "kmod= $kmod nmod= $nmod\n";
		    my $command="-raxml -model $model";
		    my $label="${model}";
		    my $msa_new=Remove_extension($msa);
		    $msa_new="${msa_new}_${name}_$model";
		    if($chain){$command="$command -chain $chain";}
		    
		    if($wmod){
			$label="${label}_iwt$iwt";
			$msa_new="${msa_new}_iwt$iwt";
			$command="${command} -iwt $iwt";
		    }
		    $label="${label}_HB${HB}_FL${flux}_rate${rate}";
		    if($HB==0){
			$command="${command} -nohb";
			$msa_new="${msa_new}_noHB";
		    }else{
			$msa_new="${msa_new}_HB";
		    }
		    if($flux==0){
			$command="${command} -noflux";
			$msa_new="${msa_new}_*_exch";
		    }else{
			$msa_new="${msa_new}_*_flux";
		    }
		    $command="${command} -rate $rate";
		    my $run_Prot_evol=0;
		    if($kmod==0 && 
		       ($model eq $smodel || ($model eq $wmodel && $iw>1))){
			$command="${command} -noreuse";
			$run_Prot_evol=1;
		    }
		    $msa_new="${msa_new}_rate${rate}.fasta";
		    if($norun){
			my $file_log=`ls -1 $msa_new`;
			if($file_log){
			    chomp $file_log;
			    $file_log=Remove_extension($file_log).".log";
			    Examine_tree($command, $label, $msa_new, $file_log);
			}
		    }else{
			Run_model($SSCPE, $command, $label, $msa_new);
			if($run_Prot_evol){sleep 700; $run_Prot_evol=0;}
			else{sleep 10;}
		    }
		    $kmod++; $nmod++;
		}
	    }
	}
    }
}
if($norun){
    print "Global results printed in file $name_all\n";
    close $f_all;
}

sub Examine_tree{
    my ($command, $label, $msa_new, $file_log) = @_;
    my $Results="Diff_${supfam}_${label}.txt";
    my $out="$Prog_K2 -rt $ref_tree -ct ${msa_new}.raxml.bestTree ".
	"-r -t $Results\n";
    print $out;
    `$out`;

    my $KS0=0; my $KS1=0; my $KS2=0;
    my $Kv1=0; my $Kv21=0;my $Kv22=0; my $RF=0;
    my $file=$Results;
    if(!-e $file){
	print "WARNING, file $file was not written\n";
	return;
    }else{
	print "Reading $file\n";
	my $l=0;
	open(my $fh, '<', $file);
	while (my $row = <$fh>){
	    $l++;
	    if($l!=2){next;}
	    my @word=split(/\s+/, $row);
	    $KS0=$word[3]; $KS1=$word[4]; $KS2=$word[6];
	    $Kv1=$word[5]; $Kv21=$word[7]; $Kv22=$word[8];
	    $RF=$word[9];
	    print "$KS0 $KS1 $KS2 $Kv1 $Kv21 $Kv22 $RF\n";
#Ploop_C2 - Ploop_C2	1.91	1.0768	0.5282	0.8445	0.4580	1.0983	2
	}
	close $fh;
    }

    my $LogLik=0; my $ntaxa=0; my $nbranch=0; my $nsite=0;
    $file=$file_log;
    print "Reading $file\n";

    if(!-e $file){
	print "WARNING, file $file was not written\n";
	$file="${msa_new}.raxml.log";
    }
    if(!-e $file){
	print "WARNING, file $file was not written\n";
    }else{
	open(my $fh, '<', $file);
	while (my $row = <$fh>){
	    my @word=split(/\s+/, $row);
	    my $nw=scalar(@word);
	    if($nw==0){
		next;
	    }elsif(substr($word[0],0,6) eq "LogLik"){
		$LogLik=$word[1]; last;
	    }elsif($nw>1 && substr($word[1],0,6) eq "LogLik"){
		$LogLik=$word[2]; last;
	    }elsif($ini_all==0){
		if($nw<5 || $word[1] ne "taxa,"){next;}
		$ntaxa=$word[0]; $nbranch=$word[2]; $nsite=$word[4];
		$ini_all=1;
		print $f_all "# ntaxa= $ntaxa nbranch= $nbranch ",
		"sites=$nsite\n"; 
	    }
	}
	close $fh;
    }
    my $ll=sprintf("%.0f", $LogLik);
    print $f_all "$label\t$ll\t$KS1\t$KS2\t$RF\t$Kv1\t$Kv21\t$Kv22\n";

}

sub Run_model{
    my ($SSCPE, $command, $label, $msa_new) = @_;

    my $Results="Diff_${supfam}_${label}.txt";

    print "label= $label\n";
    print "command= $command\n";
    print "msa= $msa_new\n";

    my $script="tmp_${label}";
    open(my $fo, '>', $script);
    if($SSCPE==0){
	`cp $msa $msa_new`;
	print $fo "$Prog_raxml --msa $msa_new";
    }elsif($pdblist){
	print $fo "$Prog_SSCPE -ali $msa -pdblist $pdblist -pdbdir $pdbdir";
    }else{
	print $fo "$Prog_SSCPE -ali $msa -pdb ${pdbdir}/$pdb";
    }
    print $fo " $command\n";
    my $out="$Prog_K2 -rt $ref_tree -ct ${msa_new}.raxml.bestTree ".
	"-r -t $Results\n";
    #print $fo "echo $out";
    print $fo $out;
    print $fo "rm -f ${msa_new}.raxml.rba\n";
    print $fo "rm -f ${msa_new}.raxml.bestModel\n";
    print $fo "rm -f ${msa_new}.raxml.mlTrees\n";
    print $fo "rm -f ${msa_new}.raxml.startTree\n";
    print $fo "rm -f ${msa_new}.raxml.reduced.phy\n";
    close $fo;
    `chmod u+x $script`;
    `$run $script`;
}

sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}

sub help{

    print "ERROR, PDB file and alignment file must be specified\n";
    print
	"USAGE: $0 \n",
	" -ali <MSA file> (FASTA)\n",
	" -pdbdir <Path to PDB>\n",
	" -pdblist <list of PDB files> line: pddbcode chain\n",
	" -pdb   <single PDB file>\n",
	" -chain <single PDB chain> (default: first chain)\n",
	" -tree <Reference tree>\n",
	" -norun <Do not infer trees, only compare them>\n",
	"\n",
	"Example:\n",
	"script_run_SSCPE_models.pl -pdbdir /ngs/databases/pdb -pdblist Ploop.PCAli.pdb.list -ali Ploop.PCAli.fas -tree Ploop.PCAli.unroot.tree\n";
}
