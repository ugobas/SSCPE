#!/usr/bin/env perl 
use strict;
use warnings;
use Getopt::Long;
use Cwd qw(getcwd);
use File::Copy;
use File::Basename;
use Config;

my @iwts=(5,10,20); #(5,10,20);
my @fluxes=(1);
my @Halpern=(1);
my @rates=(1);
my @MODELS=(#"LG","WAG","JTT",   # Empirical
	    "MF",
	    "WT",    # STAB "DDG",
	    "DE","RMSD",  # STRUCT
	    "DEWT",
	    "RMSDWT", # SSCPE
	    "DEMF","RMSDMF"
	   ); # $allmut==1

my $wmodel="DE"; # First model for whicih iwt is relevant
my $smodel="MF";

my $dir_SSCPE="/data/ubastolla/BIN/SSCPE";
my $Prog_SSCPE="${dir_SSCPE}/SSCPE.pl";
my $Prog_K2="${dir_SSCPE}/k2_mat.pl";
my $Prog_raxml="${dir_SSCPE}/raxml-ng";

my $submit="qsubmit.pl";
my $queue="x86_64";
my $mem=4;
my $pdbdir="";
my $pdblist="";

my $supfam="";
my $ref_tree="";
my $msa="";
my $pdb="";
my $chain="";

print "Script $0 author ",
    "Ugo Bastolla <ubastolla\@cbm.csic.es>\n",
    "It needs an input MSA (-ali), a pdb file either list (-pdblist -pdbdir) ",
    "or single (-pdb -chain) and reference tree (-tree).\n",
    "It runs the program SSCPE.pl, which generates site-specific ",
    "folding-stability and structure constrained substitution models ",
    "and adopts them for inferring a phylogenetic tree with RAxML-NG ",
    "and compares the inferred tree with the reference tree with k2_mat.pl ",
    "for all models and different options\n\n";

# Input arguments
if(scalar(@ARGV)<2){help();}
chomp($ARGV[scalar(@ARGV)-1]);
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-ali"){
	$i++; $msa=$ARGV[$i];
    }elsif($ARGV[$i] eq "-pdbdir"){
	$i++; $pdbdir=$ARGV[$i];
   }elsif($ARGV[$i] eq "-pdblist"){
	$i++; $pdblist=$ARGV[$i];
   }elsif($ARGV[$i] eq "-pdb"){
	$i++; $pdb=$ARGV[$i];
    }elsif($ARGV[$i] eq "-chain"){
	$i++; $chain=$ARGV[$i];
    }elsif($ARGV[$i] eq "-tree"){
	$i++; $ref_tree=$ARGV[$i];
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
if($pdb eq "" && $pdblist eq ""){
    print "ERROR, PDB file(s) must be provided with option -pdb or -pdblist\n";
    help();
}
if($msa eq ""){
    print "ERROR, alignment file must be provided with option -ali <file>\n";
    help();
}
my @word=split(/\./, $msa);
$supfam=$word[0];
print "Superfamily $supfam\n";

my $name;
if($pdb){
    if($chain eq ""){$chain="A";}
    @word=split(/\//, $pdb);
    my $prot=Remove_extension($word[scalar(@word)-1]);
    $name="${prot}${chain}";
}else{
    @word=split(/\//, $pdblist);
    $name=Remove_extension($word[scalar(@word)-1]);
}

my $nmod=0;  my $iw=0; 
foreach my $iwt (@iwts){
    $iw++; my $imod=0; my $wmod=0;
    foreach my $model (@MODELS){
	$imod++; my $kmod=0;
	if($model eq $wmodel){$wmod=1;}
	#if($imod<4){next;}
	if($wmod==0 && $iw > 1){next;}
	print "Model $model $imod\n";
	my $SSCPE=1; $kmod=0; 
	if($model eq "LG" || $model eq "WAG" || $model eq "JTT"){
	    $SSCPE=0;
	    for(my $gamma=0; $gamma<=1; $gamma++){
		my $label="${model}_G${gamma}";
		my $command="--model $model";
		my $msa_new="${msa}_${label}";
		if($gamma){$command="${command}+G4"};
		Run_model($SSCPE, $command, $label, $msa_new);
		print "kmod= $kmod nmod= $nmod\n";
		$kmod++; $nmod++;
	    }
	    next;
	} 
	# SSCPE model
	foreach my $HB (@Halpern){
	    foreach my $rate(@rates){
		foreach my $flux (@fluxes){
		    my $label="${model}";
		    my $msa_new=Remove_extension($msa);
		    $msa_new="${msa_new}_${name}_$model";
		    my $command="-chain $chain -raxml -model $model";
		    
		    if($wmod){
			$label="${label}_iwt$iwt";
			$msa_new="${msa_new}_iwt$iwt";
			if($model eq $wmodel && $kmod==0){
				$command="${command} -noreuse";
			}
			$command="${command} -iwt $iwt";
		    }
		    $label="${label}_HB${HB}_FL${flux}_rate${rate}";
		    if($HB==0){
			$command="${command} -nohb";
			$msa_new="${msa_new}_noHB";
		    }else{
			$msa_new="${msa_new}_HB";
		    }
		    if($flux==0){
			$command="${command} -noflux";
			$msa_new="${msa_new}_*_exch";
		    }else{
			$msa_new="${msa_new}_*_flux";
		    }
		    $command="${command} -rate $rate";
		    $msa_new="${msa_new}_rate${rate}.fasta";
		    Run_model($SSCPE, $command, $label, $msa_new);
		    print "kmod= $kmod nmod= $nmod\n";
		    if($kmod==0 && ($model eq $smodel || $model eq $wmodel)){  # || $imod ==4
			sleep 300;
		    }else{sleep 30;}
		    $kmod++; $nmod++;

		}
	    }
	}
    }
}

sub Run_model{
    my ($SSCPE, $command, $label, $msa_new) = @_;

    print "label= $label\n";
    print "command= $command\n";
    print "msa= $msa_new\n";

    my $Results="Diff_${supfam}_${label}.txt";
    my $script="tmp_${label}";
    open(my $fo, '>', $script);
    if($SSCPE==0){
	`cp $msa $msa_new`;
	print $fo "$Prog_raxml --msa $msa_new";
    }elsif($pdblist){
	print $fo "$Prog_SSCPE -ali $msa -pdblist $pdblist -pdbdir $pdbdir";
    }else{
	print $fo "$Prog_SSCPE -ali $msa -pdb ${pdbdir}/$pdb";
    }
    print $fo " $command\n";
    my $out="$Prog_K2 -rt $ref_tree -ct ${msa_new}.raxml.bestTree ".
	"-r -t $Results\n";
    #print $fo "echo $out";
    print $fo $out;
    print $fo "rm -f ${msa_new}.raxml.rba\n";
    print $fo "rm -f ${msa_new}.raxml.bestModel\n";
    print $fo "rm -f ${msa_new}.raxml.mlTrees\n";
    print $fo "rm -f ${msa_new}.raxml.startTree\n";
    print $fo "rm -f ${msa_new}.raxml.reduced.phy\n";
    close $fo;
    `chmod u+x $script`;
    `$submit -s $script -q $queue --mem $mem`;
}

sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}

sub help{

    print "ERROR, PDB file and alignment file must be specified\n";
    print
	"USAGE: $0 \n",
	" -ali <MSA file> (FASTA)\n",
	" -pdbdir <Path to PDB>\n",
	" -pdblist <list of PDB files> line: pddbcode chain\n",
	" -pdb   <single PDB file>\n",
	" -chain <single PDB chain> (default: first chain)\n",
	" -tree <Reference tree>\n",
	"\n";
}
