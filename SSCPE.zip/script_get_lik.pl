#!/usr/bin/env perl 
use strict;
use warnings;

my $clean=1;

#my $msa="";
#for(my $i=0; $i<scalar(@ARGV); $i++){
#    if($ARGV[$i] eq "-ali"){
#	$i++; $msa=$ARGV[$i];
#    }elsif($ARGV[$i] eq "-h"){
#	help();
#    }else{
#	print "WARNING, unknown option ",$ARGV[$i],"\n";
#    }
#}
#if($msa eq ""){
#   print "ERROR, argument msa is mandatory\n"; die;
#}
#my $raxmlout="${msa}.raxml.log";

my @files=`ls -1 *.raxml.log`;
my $n=0; my $m=0;
foreach my $raxmlout (@files){
    chomp $raxmlout;
    my $msa=Remove_extension(Remove_extension($raxmlout));
    my $name=Remove_extension($msa);
    my $output=$name.".log";
    print "$raxmlout -> $output\n"; #die;

    my $LogLik=0;

    if(-e $raxmlout){
	print "\nReading RAxML-NG results in ${raxmlout}\n";
	open(my $fh, '<', $raxmlout);
	my $taxa=0; my $nsite=0;
	while (my $row = <$fh>){
	    if(length($row)< 18){next;} 
	    if(substr($row, 0, 12) eq "Final LogLik"){
		my @word=split(/\s+/, $row);
		$LogLik=$word[2]; last;
	    }elsif(substr($row, 11, 6) eq "Loaded"){
		my @word=split(/\s+/, $row);
		$taxa=$word[4]; $nsite=$word[7];
	    }elsif(substr($row, 0, 6) eq "Loaded"){
		my @word=split(/\s+/, $row);
		$taxa=$word[3]; $nsite=$word[6];
	    }
	}
	close $fh;
	my $branches=2*$taxa-3; my $lnorm=0;
	if($nsite){$lnorm=$LogLik/($nsite*$branches);}
	my $out=sprintf("LogLikelihood= %.3f /(n*branches): %.5g\n",
			$LogLik, $lnorm);
	if($LogLik){
	    $n++; 
	    print "$n $raxmlout -> $output\n";
	    open(my $fo, '>>', $output);
	    print $fo $out;
	    close $fo;
	    if($clean){
		#`rm -f ${name}*.site_*.txt`;
		#`rm -f ${name}*.partition*`;
		my $tmp="${msa}.raxml.rba"; `rm -f $tmp`;
		$tmp="${msa}.raxml.reduced.*"; `rm -f $tmp`;
		$tmp="${msa}.raxml.startTree"; `rm -f $tmp`;
		$tmp="${msa}.raxml.bestModel"; `rm -f $tmp`;
		#$tmp="${msa}.raxml.mlTrees"; `rm -f $tmp`;
		$tmp="${msa}.raxml.log"; `rm -f $tmp`;
		$tmp="${msa}"; `rm -f $tmp`;
	    }
	}else{
	    $m++;
	}
    }else{
	print "WARNING RAxML-NG results not found in ${raxmlout}\n";
	$m++;
    }
}
print "$n values of LogLik transcribed, $m not found\n";

sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out=sprintf("%s.%s",$out,$word[$i]);
    }
    return $out;
}

sub help{
    print
	"USAGE: ",$0,
	" -ali <MSA file>\n",
	"\n";
    die;
}
