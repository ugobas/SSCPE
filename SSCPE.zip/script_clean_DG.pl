#!/usr/bin/env perl 
use strict;
use warnings;

my @List2=`ls -1 *.DeltaG`;
my $n_exist=0; my $n_no=0;
foreach my $file (@List2){
    chomp $file;
    my $f=Remove_extension($file);
    if(-e $f){
	print "$f exists\n"; $n_exist++;
    }else{
	print "$f does not exist\n"; $n_no++;
	`rm -f $file`;
    }
}
print "$n_exist DeltaG files are associated to .fasta files, $n_no are not\n",
"They have been deleted\n";

sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out=sprintf("%s.%s",$out,$word[$i]);
    }
    return $out;
}
