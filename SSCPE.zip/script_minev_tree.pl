#!/usr/bin/env perl 
use strict;
use warnings;

my $ext_in="mlTrees";
my $ext_out="minBrTree";
my $ext_len="BL";
my $print_all=1;

my $ali="";
my $model="";
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-ali"){
	$i++; $ali=$ARGV[$i];
    }elsif($ARGV[$i] eq "-ext"){
	$i++; $ext_in=$ARGV[$i];
    }elsif($ARGV[$i] eq "-model"){
	$i++; $model=$ARGV[$i];
    }elsif($ARGV[$i] eq "-h"){
	help();
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
if($ali eq ""){print "ERROR, arguments -ali is mandatory\n"; help();}
	
my $name=Remove_fasta($ali);
my $search_name=$name;
if($model ne ""){
    $name=$name.".$model";
    $search_name=$search_name.".*.$model";
}
$search_name=$search_name.".*.$ext_in";

my @trees=`ls -1 $search_name`;
if(scalar(@trees)==0){
    print "Warning, file $search_name does not exist, exiting\n"; die;
}
my $tree_min=""; my $b1_min=1000; my $ntot=0; 
foreach my $tree_file (@trees){
    chomp $tree_file;
    my $output=Remove_extension($tree_file, 1);
    $output=$output.".$ext_out";
    if(-e $output){
	print "Minimum length $tree_file already exists, exiting\n";
	next;
    }
    my ($BL, $n, $tree, $b1)=Read_BL($tree_file);
    if($n==0){next;}
    if($ntot==0 || $b1<$b1_min){$b1_min=$b1; $tree_min=$tree;}
    $ntot+=$n;
    print "Writing minimum branch length tree in $output\n"; 
    open(my $fo, '>', $output);
    print $fo $tree, "\n";
    close $fo;
}

if(scalar(@trees) > 1){
    $b1_min=sprintf("%.3g", $b1_min);
    print "Shortest branch lengths BL=$b1_min\n";
    if($print_all==0){die;} 
    my $output=$name.".$ext_out";
    if(!-e $output){
	print "Writing shortest branch lengths tree in $output\n";
	open(my $fo, '>', $output);
	print $fo $tree_min, "\n";
	close $fo;
	if(0){
	    my $output2=$name.".$ext_len";
	    print "Writing value of branch lengths in $output2\n";
	    open($fo, '>', $output2);
	    print $fo "$output sum_BL= $b1_min\n";
	    close $fo;
	}
    }
}

sub Remove_fasta{ #($ali)
    my @word=split(/\./, $ali);
    my $out=$word[0];
    for(my $i=1; $i<scalar(@word); $i++){
	if($word[$i] eq "fasta"){last;}
	$out=$out.".$word[$i]";
    }
    return($out);
}

sub Read_BL{ #($tree_file)
    my $file=$_[0];
    chomp $file;
    my @BL=(); my $n=0;
    if(!-e $file){
	print "ERROR, $file does not exist\n";
	return(\@BL, 0, "", 1000);
    }
    open(my $fh, '<', $file);
    my $b1_min=1000; my $tree_min=""; my $nbranches=0;
    while (my $row = <$fh>){
	chomp $row;
	my $b1=0; my $b2=0; my $nb=0; my $ib=-1;
	for(my $i=0; $i<length($row); $i++){
	    my $x=substr($row, $i, 1);
	    if($x eq ":"){
		$ib=$i+1;
	    }elsif(($x eq ")" || $x eq "," || $x eq ";") && $ib >=0){
		my $l=$i-$ib;
		$b=substr($row, $ib, $l);
		$nb++; $b1+=$b; #$b2+=$b*$b; 
		$ib=-1;
	    }
	}
	if($n==0 || $b1 < $b1_min){
	    $b1_min=$b1; $tree_min=$row;
	}
	$BL[$n]=$b1; $n++;
	if($nbranches==0){$nbranches=$nb;}
	elsif($nb != $nbranches){
	    print "ERROR, different number of branches in $file: ",
	    "$nbranches and $nb\n";
	}
    }
    close $fh;
    print "$n trees found in $file, minimum BL = ",
    sprintf("%.3g", $b1_min),"\n";
    return(\@BL, $n, $tree_min, $b1_min);
}

sub Remove_extension{
    my ($string, $n) = @_;
    my @word=split(/\./, $_[0]);
    if($n eq ""){$n=1;}
    if($n >= scalar(@word)){
	print "ERROR, I can't remove $n words from ",scalar(@word),"\n";
	return $string;
    }
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-$n); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}

sub help{
    print "Program $0 ",
    "It selects the tree with minimum sum of branch lengths among a set\n",
    "USAGE: ",$0,
    " -ali <alignment name> (mandatory)\n",
    " -ext <Extension of comparison trees> default: $ext_in\n",
    " -model <Model used for inferring the tree>\n",
    "\n";
    die;
}
