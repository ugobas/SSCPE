#!/usr/bin/perl
use strict;
use warnings;

my $script_k2="/data/ubastolla/BIN/SSCPE/k2_mat.pl";

my @list=("1B04","1BP2","1HQC","1IU4","1M53","1ONR","1QAM","1S3I","2A0N");
#my @list=("1HQC");

my $prot="";

if(scalar(@ARGV)<2){help();}
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-tree"){
	$i++; $prot=$ARGV[$i];
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
#foreach my $prot (@list){

# build concatenated tree
my $All_Trees=$prot."_all.tree";
if(-e $All_Trees){`rm -f $All_Trees`;}
my @Trees=`ls -1 ${prot}*.bestTree`;
my $n=0; my $tree;
foreach $tree (@Trees){
    chomp($tree); $n++;
    `cat $tree >> $All_Trees`;
}
print "$n trees concatenated in file $All_Trees\n";
# Compare trees
my $k=0;
foreach $tree (@Trees){
    my @word=split(/\./, $tree);
    my $diff="Diff.${prot}";
    if(scalar(@word)>3){$diff=$diff.".${word[2]}";}
    else{$diff=$diff.".${word[1]}";}
    $diff=$diff.".txt";
    if(!-e $diff){
	print "Comparing $tree with $All_Trees, writing results to $diff\n";
	print "$script_k2 -rt $tree -ct $All_Trees -t -r -n\n";
	`$script_k2 -rt $tree -ct $All_Trees -t -r -n`;
	`mv ${All_Trees}.tab $diff`;
	$k++;
    }
}
if(1 || $k){
    my $mean="Diff.${prot}.Mean";
    open(my $fo, '>', $mean);
    my $header=
	"# Model KS0 KS1 Scale KS2 Scale1  Scale2  RF Branch Support_K2 Sum_br\n";
    print $fo $header;
    close $fo;
    `grep Mean Diff.${prot}*txt >> $mean`;
    print "Global results written to $mean\n";
}else{
    print "Nothing to do, $n trees had already been compared\n";
}

sub help{
    print "ERROR, tree names must be specified\n";
    print
	"USAGE: $0 -tree <TREE_NAME>\n",
	"\n",
	"Examples:\n",
	"$0 -tree 1HQC\n",
	"which requires that tree files named 1HQC*.bestTree exist\n";
    die;
}
